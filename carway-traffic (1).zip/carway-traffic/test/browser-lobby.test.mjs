// CARWAY TRAFFIC — Browser tests: 3D lobby, menu navigation, garage
// showroom, upgrades screen, magnet power-up, HUD badges, settings.
// Run: `node test/browser-lobby.test.mjs` (game at :8080).
// All waits poll GAME state, so results are deterministic under SwiftShader.
import { chromium } from 'playwright';

const URL = process.env.CARWAY_URL || 'http://127.0.0.1:8080/index.html?nointro=1';
let pass = 0, fail = 0;
const t = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else { fail++; console.log(`  ❌ ${name} ${extra}`); }
};

const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader'] });

// Fresh browser context per scenario = fresh localStorage profile.
// Open the nav drawer and wait until its slide transition fully settles
// (sandbox SwiftShader frames can stretch CSS transitions over seconds).
async function openNav(page) {
  await page.click('#btn-nav');
  await page.waitForFunction(
    () => document.querySelector('#nav-drawer').getBoundingClientRect().left >= -0.5,
    null, { timeout: 15000 });
}

async function freshPage(viewport = { width: 390, height: 844 }, url = URL) {
  const ctx = await browser.newContext({ viewport, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto(url, { waitUntil: 'networkidle' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 20000 });
  return { page, errors, ctx };
}

async function startRun(page) {
  await page.click('#btn-start');
  await page.waitForFunction(() => window.__carway.state === 'playing' && window.__carway.distance > 5,
    null, { timeout: 60000 });
}

// Spawn a pickup orb of a forced type ahead of the player.
async function dropPickup(page, type) {
  await page.evaluate((type) => {
    const g = window.__carway;
    g.pickups._spawn();
    const p = g.pickups.items.find((p) => p.active);
    p.type = type;
    g.pickups._showType(p);
    p.root.position.set(g.player.x, 0, -2);
  }, type);
}

// Park all traffic + silence natural coin spawns (test coins placed by hand).
async function sterileRun(page) {
  await page.evaluate(() => {
    const g = window.__carway;
    g.traffic.graceLeft = 1e9;
    for (const c of g.traffic.cars) { c.active = false; c.group.visible = false; }
    for (const h of g.traffic.hazards) { h.active = false; h.group.visible = false; }
    for (const c of g.coins.items) { c.active = false; c.root.visible = false; }
    g.coins.nextGap = 1e9;
  });
}

// Place one live coin at (player.x + dx, z). Returns nothing.
async function placeCoin(page, dx, z) {
  await page.evaluate(({ dx, z }) => {
    const g = window.__carway;
    const c = g.coins.items.find((c) => !c.active);
    c.active = true; c.root.visible = true;
    c.baseY = 0.9;
    c.root.position.set(g.player.x + dx, 0, z);
  }, { dx, z });
}

// ------------------------------------------------------------------ lobby
console.log('— Lobby: 3D roadside garage, live traffic, menu —');
{
  const { page, errors, ctx } = await freshPage();
  try {
    const boot = await page.evaluate(() => ({
      state: __carway.state,
      lobby: __carway.lobby.visible,
      traffic: __carway.traffic.cars.filter((c) => c.active).length,
      worksGap: __carway.traffic.nextWorksGap,
      works: __carway.traffic.worksSpawned,
      px: +__carway.player.mesh.position.x.toFixed(2),
      pz: +__carway.player.mesh.position.z.toFixed(2),
    }));
    t('boots into the menu with the lobby scene', boot.state === 'menu' && boot.lobby === true, JSON.stringify(boot));
    t('background traffic pre-warmed on the highway', boot.traffic >= 3, `cars=${boot.traffic}`);
    t('selected car parked on the turntable spot', boot.px === -9 && boot.pz === 6, `x=${boot.px} z=${boot.pz}`);
    t('roadworks suppressed in the lobby', boot.worksGap === Infinity && boot.works === 0);
    const chrome = await page.evaluate(() => ['btn-start', 'btn-nav', 'btn-settings']
      .map((id) => { const b = document.getElementById(id); return b && !b.disabled && b.offsetParent !== null; }));
    t('PLAY / nav toggle / settings gear all live', chrome.every(Boolean), JSON.stringify(chrome));
    t('best-score chip shows up top', await page.evaluate(() => {
      const b = document.getElementById('best-line');
      const r = b.getBoundingClientRect();
      return b.offsetParent !== null && r.top < 160 && Math.abs((r.left + r.right) / 2 - 195) < 120;
    }));
    await openNav(page);
    await page.waitForFunction(() => document.querySelector('#nav-drawer').classList.contains('open'));
    const drawer = await page.evaluate(() => ['btn-garage', 'btn-upgrades', 'btn-missions']
      .map((id) => { const b = document.getElementById(id); return b && !b.disabled && b.offsetParent !== null; }));
    t('drawer reveals GARAGE / UPGRADES / MISSIONS', drawer.every(Boolean), JSON.stringify(drawer));
    await page.mouse.click(320, 422); // dimmed area right of the open drawer
    await page.waitForFunction(() => !document.querySelector('#nav-drawer').classList.contains('open'));
    t('drawer closes cleanly via backdrop', true);
    // Traffic flows: lobby distance advances, rows keep spawning.
    const d0 = await page.evaluate(() => __carway.lobbyDist);
    await page.waitForFunction((d) => window.__carway.lobbyDist > d + 10, d0, { timeout: 30000 });
    t('background traffic flows continuously', true);
    t('still no roadworks after the flow', await page.evaluate(() => __carway.traffic.worksSpawned) === 0);
    // Frozen lobby: ONLY traffic cars move; road, barriers, garage, camera
    // and display car hold exactly still.
    const frozen = () => page.evaluate(() => ({
      segZ: __carway.road.segments.map((s) => +s.position.z.toFixed(4)),
      cam: __carway.camera.position.toArray().map((v) => +v.toFixed(4)),
      mesh: __carway.player.mesh.position.toArray().map((v) => +v.toFixed(4)),
      rot: [__carway.player.mesh.rotation.x, __carway.player.mesh.rotation.y,
        __carway.player.mesh.rotation.z].map((v) => +v.toFixed(4)),
      cars: __carway.traffic.cars.filter((c) => c.active).map((c) => +c.group.position.z.toFixed(3)),
    }));
    const f0 = await frozen();
    await page.waitForTimeout(1500);
    const f1 = await frozen();
    const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
    t('lobby camera frozen', same(f0.cam, f1.cam), JSON.stringify(f0.cam));
    t('lobby road + barriers frozen', same(f0.segZ, f1.segZ));
    t('display car frozen', same(f0.mesh, f1.mesh) && same(f0.rot, f1.rot));
    t('traffic advances under its own velocity',
      f1.cars.length > 0 && f1.cars.some((z, i) => Math.abs(z - (f0.cars[i] ?? z)) > 0.05),
      `${JSON.stringify(f0.cars)} -> ${JSON.stringify(f1.cars)}`);
    // Forward driving: cars travel -z (nose-first, away from the lobby
    // camera), hold their lanes, stay upright, wheels rolling forward.
    const fwd = await page.evaluate(() => {
      const g = window.__carway;
      const sample = () => {
        const out = {};
        g.traffic.cars.forEach((c, i) => {
          if (c.active) out[i] = {
            x: c.group.position.x, z: c.group.position.z,
            ry: c.group.rotation.y, w: c.wheels[0].rotation.x,
          };
        });
        return out;
      };
      return new Promise((resolve) => {
        const a = sample();
        setTimeout(() => resolve({ a, b: sample() }), 1500);
      });
    });
    const lodFar = await page.evaluate(() => __carway.traffic.lodFar);
    const pairs = Object.keys(fwd.b).filter((i) => fwd.a[i]).map((i) => ({
      x: fwd.b[i].x, z: fwd.b[i].z, ry: fwd.b[i].ry,
      dz: fwd.b[i].z - fwd.a[i].z, dw: fwd.b[i].w - fwd.a[i].w,
    }));
    const moved = pairs.filter((p) => Math.abs(p.dz) > 0.3);
    t('lobby traffic drives forward (-z, nose-first)',
      moved.length > 0 && moved.every((p) => p.dz < 0),
      JSON.stringify(pairs.map((p) => +p.dz.toFixed(2))));
    t('lobby cars hold their lanes',
      pairs.length > 0 && pairs.every((p) => [0, 3.2].some((v) => Math.abs(Math.abs(p.x) - v) < 0.05)),
      JSON.stringify(pairs.map((p) => +p.x.toFixed(1))));
    t('lobby cars stay upright (no flips)',
      pairs.length > 0 && pairs.every((p) => Math.abs(p.ry) < 0.01),
      JSON.stringify(pairs.map((p) => +p.ry.toFixed(3))));
    // Far cars (beyond lodFar) skip wheel spins by design (LOD perf rule),
    // so the roll-direction assert only covers near, full-detail cars.
    const nearMoved = pairs.filter((p) => Math.abs(p.dz) > 0.3 && p.z > -lodFar);
    t('wheels roll forward (rotation.x decreases)',
      nearMoved.length > 0 && nearMoved.every((p) => p.dw < 0),
      JSON.stringify(pairs.map((p) => `${+p.z.toFixed(0)}:${+p.dw.toFixed(2)}`)));
    // No road furniture inside the garage pad: barriers/columns must never
    // pass through the building, floor or display car.
    const intruders = await page.evaluate(() => {
      const bad = [];
      const v = new (Object.getPrototypeOf(__carway.camera.position).constructor)();
      for (const seg of __carway.road.segments) {
        seg.traverse((o) => {
          if (!o.isMesh) return;
          o.getWorldPosition(v);
          if (v.x > -19 && v.x < -7 && v.z > -7 && v.z < 19) {
            bad.push([+v.x.toFixed(1), +v.y.toFixed(1), +v.z.toFixed(1)]);
          }
        });
      }
      return bad;
    });
    t('no road furniture inside the garage pad', intruders.length === 0, JSON.stringify(intruders));
    // No dead buttons: every screen opens and returns.
    for (const [btn, state, viaNav] of [['btn-garage', 'garage', true], ['btn-upgrades', 'upgrades', true], ['btn-missions', 'missions', true], ['btn-settings', 'settings', false]]) {
      if (viaNav) await openNav(page);
      await page.click(`#${btn}`);
      await page.waitForFunction((s) => window.__carway.state === s, state, { timeout: 5000 });
      const back = { garage: '#btn-garage-back', upgrades: '#btn-upgrades-back', missions: '#btn-missions-back', settings: '#btn-settings-back' }[state];
      await page.click(back);
      await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
    }
    t('garage/upgrades/missions/settings open + return (no dead buttons)', true);
    // Missions screen renders all three missions with live progress.
    await openNav(page);
    await page.click('#btn-missions');
    await page.waitForFunction(() => window.__carway.state === 'missions', null, { timeout: 5000 });
    const mis = await page.evaluate(() => [...document.querySelectorAll('#missions-list .mission-row')].map((r) => ({
      name: r.querySelector('.mission-name').textContent, prog: r.querySelector('.mission-progress').textContent,
    })));
    t('missions screen lists 3 missions with progress',
      mis.length === 3 && mis.every((m) => m.name && m.prog), JSON.stringify(mis));
    await page.click('#btn-missions-back');
    await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
    t('lobby survives screen-hopping (no traffic reset pop)',
      await page.evaluate(() => __carway.lobby.visible && __carway.traffic.cars.some((c) => c.active)));
    // Garage turntable + drag inspection.
    await openNav(page);
    await page.click('#btn-garage');
    await page.waitForFunction(() => window.__carway.state === 'garage', null, { timeout: 5000 });
    const r0 = await page.evaluate(() => __carway.player.mesh.rotation.y);
    await page.waitForTimeout(1500);
    const r1 = await page.evaluate(() => __carway.player.mesh.rotation.y);
    t('showroom car auto-rotates', Math.abs(r1 - r0) > 0.2, `rot ${r0.toFixed(2)} -> ${r1.toFixed(2)}`);
    const g0 = await page.evaluate(() => __carway.garageAngle);
    await page.mouse.move(195, 200);
    await page.mouse.down();
    await page.mouse.move(295, 200, { steps: 5 });
    await page.mouse.up();
    const g1 = await page.evaluate(() => __carway.garageAngle);
    t('drag spins the showroom car', Math.abs(g1 - g0) > 0.2, `angle ${g0.toFixed(2)} -> ${g1.toFixed(2)}`);
    // Showroom camera holds still (only the car turntable moves here).
    // First let the entry glide converge (polls game state, timing-proof).
    await page.waitForFunction(() => {
      const l = window.__carway.lobby;
      return l.camR === 9.5 && l.camH === 3.5 && l.camFov === 55; // snapped exactly
    }, null, { timeout: 120000 });
    const gc0 = await page.evaluate(() => __carway.camera.position.toArray().map((v) => +v.toFixed(4)));
    await page.waitForTimeout(1200);
    const gc1 = await page.evaluate(() => __carway.camera.position.toArray().map((v) => +v.toFixed(4)));
    t('showroom camera holds still', JSON.stringify(gc0) === JSON.stringify(gc1), JSON.stringify(gc0));
    // Purchase-gated selection: broke tap on a locked car changes nothing.
    await page.click('#btn-garage-tab-cars');
    await page.click('#car-list .paint-row:nth-child(2) button');
    await page.waitForTimeout(400);
    const gate = await page.evaluate(() => ({ car: __carway.save.data.car, coins: __carway.save.data.coins }));
    t('locked car cannot be selected for free', gate.car === 'roadster' && gate.coins === 0, JSON.stringify(gate));
    await page.click('#btn-garage-back');
    await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
    // PLAY: lobby hides, run starts, works gap restored, pose restored.
    await page.click('#btn-start');
    await page.waitForFunction(() => window.__carway.state === 'playing', null, { timeout: 10000 });
    const go = await page.evaluate(() => ({
      lobby: __carway.lobby.visible,
      worksGap: __carway.traffic.nextWorksGap < 1e8,
      rotY: +__carway.player.mesh.rotation.y.toFixed(3),
      x: +__carway.player.mesh.position.x.toFixed(2),
    }));
    t('PLAY hides lobby, restores works + driving pose',
      go.lobby === false && go.worksGap && Math.abs(go.rotY) < 0.05 && go.x === 0, JSON.stringify(go));
    t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// --------------------------------------------------------------- upgrades
console.log('— Upgrades screen: cards, prices, purchase rules —');
{
  const { page, errors, ctx } = await freshPage();
  try {
    await page.evaluate(() => { __carway.save.data.coins = 1000; __carway.save._persist(); });
    await openNav(page);
    await page.click('#btn-upgrades');
    await page.waitForFunction(() => window.__carway.state === 'upgrades', null, { timeout: 5000 });
    const cards = await page.evaluate(() => [...document.querySelectorAll('.up-card')].map((card) => ({
      id: card.dataset.upgrade,
      level: card.querySelector('.up-level').textContent,
      dur: card.querySelector('.up-dur').textContent,
      sub: (card.querySelector('.up-sub') || {}).textContent || '',
      price: card.querySelector('.up-price').textContent,
      btn: card.querySelector('.up-btn').textContent,
      disabled: card.querySelector('.up-btn').disabled,
    })));
    t('four upgrade cards rendered', cards.length === 4, cards.map((c) => c.id).join(','));
    const [sh, mg, cx, ju] = cards;
    t('shield card: LV + duration ladder + price',
      sh.level === 'LV 1/5' && sh.dur.includes('4s') && sh.dur.includes('5s') && sh.price.includes('100') &&
      sh.btn === 'UPGRADE' && sh.disabled === false, JSON.stringify(sh));
    t('magnet card shows radius ladder too',
      mg.level === 'LV 1/5' && mg.dur.includes('5s') && mg.dur.includes('6s') && mg.sub.includes('8m'),
      JSON.stringify(mg));
    t('2x card: 6s -> 7s ladder',
      cx.dur.includes('6s') && cx.dur.includes('7s'), JSON.stringify(cx));
    t('jump card: 1.15s -> 1.25s airtime ladder',
      ju.dur.includes('1.15') && ju.dur.includes('1.25'), JSON.stringify(ju));
    // Purchase: deduct only on valid buy.
    await page.click('[data-upgrade="shield"] .up-btn');
    await page.waitForTimeout(300);
    const bought = await page.evaluate(() => ({
      level: __carway.save.data.upgrades.shield,
      coins: __carway.save.data.coins,
      label: document.querySelector('[data-upgrade="shield"] .up-level').textContent,
    }));
    t('shield LV2 purchased, price deducted', bought.level === 2 && bought.coins === 900 && bought.label === 'LV 2/5',
      JSON.stringify(bought));
    // Poor: buttons disable with a visual state, nothing deducted.
    await page.evaluate(() => { __carway.save.data.coins = 0; __carway.ui.refreshUpgrades(__carway.save.data); });
    const poor = await page.evaluate(() => [...document.querySelectorAll('.up-btn')]
      .map((b) => b.disabled && b.classList.contains('poor')));
    t('unaffordable upgrades disable with poor state', poor.length === 4 && poor.every(Boolean));
    const rej = await page.evaluate(() => {
      const before = __carway.save.data.coins;
      const res = __carway.buyUpgrade('magnet');
      return { ok: res.ok, reason: res.reason, coins: __carway.save.data.coins, same: __carway.save.data.coins === before };
    });
    t('invalid purchase deducts nothing', rej.ok === false && rej.reason === 'coins' && rej.same, JSON.stringify(rej));
    // Maxed: LV5 shows MAXED, disabled.
    await page.evaluate(() => {
      for (const id of ['shield', 'magnet', 'coin2x', 'jump']) __carway.save.data.upgrades[id] = 5;
      __carway.save.data.coins = 99999;
      __carway.ui.refreshUpgrades(__carway.save.data);
    });
    const maxed = await page.evaluate(() => [...document.querySelectorAll('.up-btn')]
      .map((b) => b.textContent === 'MAXED' && b.disabled));
    t('maxed upgrades show MAXED, disabled', maxed.length === 4 && maxed.every(Boolean));
    // Persistence across reload.
    await page.evaluate(() => { __carway.save.data.upgrades.shield = 3; __carway.save._persist(); });
    await page.reload({ waitUntil: 'networkidle' });
    await page.waitForFunction(() => window.__carway, null, { timeout: 20000 });
    t('upgrade level persists after reload',
      await page.evaluate(() => __carway.save.data.upgrades.shield) === 3);
    t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// ----------------------------------------------------------------- magnet
console.log('— Magnet power-up: attraction, refresh, expiry, HUD —');
{
  const { page, errors, ctx } = await freshPage();
  try {
    await startRun(page);
    await sterileRun(page);
    // Collect: L1 duration, field visual, HUD badge with countdown.
    await dropPickup(page, 'magnet');
    await page.waitForFunction(() => window.__carway.magnet.timeLeft > 0, null, { timeout: 30000 });
    const got = await page.evaluate(() => ({
      timer: +__carway.magnet.timeLeft.toFixed(1),
      mesh: __carway.player.magnetMesh.visible,
      badge: (document.querySelector('#hud-badges .badge-magnet') || {}).textContent,
    }));
    t('magnet grants L1 duration (5s)', got.timer > 4 && got.timer <= 5, JSON.stringify(got));
    t('magnet field visual + HUD badge appear', got.mesh === true && /🧲/.test(got.badge || ''), got.badge);
    // Curved attraction: a side coin arcs in and collects exactly once.
    const c0 = await page.evaluate(() => __carway.runCoins);
    await placeCoin(page, 5.5, -5);
    const track = await page.evaluate(() => {
      const g = window.__carway;
      const c = g.coins.items.find((c) => c.active);
      return { x: +c.root.position.x.toFixed(2), z: +c.root.position.z.toFixed(2) };
    });
    await page.waitForFunction((before) => {
      const g = window.__carway;
      const c = g.coins.items.find((c) => c.active);
      if (!c) return true; // collected already
      return Math.hypot(c.root.position.x - g.player.x, c.root.position.z) < Math.hypot(before.x, before.z) - 1;
    }, track, { timeout: 30000 });
    t('side coin arcs toward the car', true, `from (${track.x},${track.z})`);
    await page.waitForFunction((n) => window.__carway.runCoins > n, c0, { timeout: 30000 });
    await page.waitForTimeout(1500); // no double-collect afterwards
    const c1 = await page.evaluate(() => window.__carway.runCoins);
    t('magnet coin collects exactly once', c1 === c0 + 1, `coins ${c0} -> ${c1}`);
    // Re-pickup refreshes the single timer (never stacks).
    await page.evaluate(() => { __carway.magnet.timeLeft = 1; });
    await dropPickup(page, 'magnet');
    await page.waitForFunction(() => window.__carway.magnet.timeLeft > 4, null, { timeout: 30000 });
    t('re-pickup refreshes the magnet timer', true);
    // Expiry hides the visual + badge.
    await page.evaluate(() => { __carway.magnet.timeLeft = 0.2; });
    await page.waitForFunction(() => window.__carway.magnet.timeLeft <= 0 &&
      !__carway.player.magnetMesh.visible &&
      !document.querySelector('#hud-badges .badge-magnet'), null, { timeout: 30000 });
    t('expired magnet clears visual + badge', true);
    // Coins outside the radius behave normally (advect past, uncollected).
    await dropPickup(page, 'magnet');
    await page.waitForFunction(() => window.__carway.magnet.timeLeft > 0, null, { timeout: 30000 });
    const far0 = await page.evaluate(() => __carway.runCoins);
    await placeCoin(page, -14, -30); // beyond L1 radius (8m)
    await page.waitForFunction(() => {
      const g = window.__carway;
      return !g.coins.items.some((c) => c.active) || g.magnet.timeLeft <= 0;
    }, null, { timeout: 60000 });
    const far1 = await page.evaluate(() => __carway.runCoins);
    t('out-of-radius coin never collected', far1 === far0, `coins ${far0} -> ${far1}`);
    t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// --------------------------------------------- coexistence, levels, layout
console.log('— Coexistence, level-driven durations, HUD layout —');
{
  const { page, errors, ctx } = await freshPage();
  try {
    await startRun(page);
    await sterileRun(page);
    // All three power-ups may run together, each with its own badge.
    await dropPickup(page, 'shield');
    await page.waitForFunction(() => window.__carway.shield.charges > 0, null, { timeout: 30000 });
    await dropPickup(page, 'magnet');
    await page.waitForFunction(() => window.__carway.magnet.timeLeft > 0, null, { timeout: 30000 });
    await dropPickup(page, 'coin2x');
    await page.waitForFunction(() => window.__carway.coin2x.timeLeft > 0, null, { timeout: 30000 });
    const co = await page.evaluate(() => ({
      timers: [+__carway.shield.timeLeft.toFixed(1), +__carway.magnet.timeLeft.toFixed(1), +__carway.coin2x.timeLeft.toFixed(1)],
      badges: ['badge-shield', 'badge-magnet', 'badge-coin2x'].map((c) =>
        (document.querySelector(`#hud-badges .${c}`) || {}).textContent),
    }));
    t('shield + magnet + 2x coexist', co.timers.every((v) => v > 0), JSON.stringify(co));
    t('all three HUD badges show countdowns', co.badges.every((b) => b && /\d/.test(b)), JSON.stringify(co.badges));
    // Badges sit below the meters; jump/nitro touch targets stay usable.
    const layout = await page.evaluate(() => {
      const badges = document.querySelector('#hud-badges').getBoundingClientRect();
      const jump = document.querySelector('#jump-wrap').getBoundingClientRect();
      const ids = ['btn-left', 'btn-jump', 'btn-right', 'btn-nitro'];
      return { above: badges.top >= jump.bottom - 1, btns: ids.map((id) => document.getElementById(id).offsetParent !== null) };
    });
    t('badges never cover meters/road info', layout.above, JSON.stringify(layout));
    t('jump/nitro touch targets stay visible', layout.btns.every(Boolean), JSON.stringify(layout.btns));
    // Magnet + 2x: attracted coin pays the doubled award, once.
    const m0 = await page.evaluate(() => __carway.runCoins);
    await placeCoin(page, 4, -4);
    await page.waitForFunction((n) => window.__carway.runCoins >= n + 2, m0, { timeout: 30000 });
    await page.waitForTimeout(1200);
    const m1 = await page.evaluate(() => window.__carway.runCoins);
    t('magnet + 2x coin pays exactly 2', m1 === m0 + 2, `coins ${m0} -> ${m1}`);
    // Maxed levels drive real gameplay durations.
    await page.evaluate(() => {
      const g = window.__carway;
      g.save.data.upgrades.shield = 5;
      g.save.data.upgrades.magnet = 5;
      g.save.data.upgrades.coin2x = 5;
      g.shield.charges = 0; g.shield.timeLeft = 0;
      g.magnet.timeLeft = 0; g.coin2x.timeLeft = 0;
    });
    await dropPickup(page, 'shield');
    await page.waitForFunction(() => window.__carway.shield.timeLeft > 0, null, { timeout: 30000 });
    await dropPickup(page, 'magnet');
    await page.waitForFunction(() => window.__carway.magnet.timeLeft > 0, null, { timeout: 30000 });
    await dropPickup(page, 'coin2x');
    await page.waitForFunction(() => window.__carway.coin2x.timeLeft > 0, null, { timeout: 30000 });
    const lv = await page.evaluate(() => ({
      shield: +__carway.shield.timeLeft.toFixed(1),
      magnet: +__carway.magnet.timeLeft.toFixed(1),
      coin2x: +__carway.coin2x.timeLeft.toFixed(1),
    }));
    t('maxed durations apply in-game (8s/10s/12s)',
      lv.shield > 7 && lv.shield <= 8 && lv.magnet > 9 && lv.magnet <= 10 && lv.coin2x > 11 && lv.coin2x <= 12,
      JSON.stringify(lv));
    // Corrupt levels are validated (clamped) when a run starts.
    await page.evaluate(() => { __carway.save.data.upgrades.shield = 99; __carway.toMenu(); });
    await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
    await startRun(page);
    t('run start clamps corrupt levels',
      await page.evaluate(() => __carway.save.data.upgrades.shield) === 5);
    t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// --------------------------------------------------------------- settings
console.log('— Settings: volumes, mute, quality, reset —');
{
  const { page, errors, ctx } = await freshPage();
  try {
    await page.click('#btn-settings');
    await page.waitForFunction(() => window.__carway.state === 'settings', null, { timeout: 5000 });
    // Volume sliders drive the sound system live.
    await page.evaluate(() => {
      const el = document.querySelector('#set-music');
      el.value = '30'; el.dispatchEvent(new Event('input', { bubbles: true }));
    });
    t('music slider sets music volume',
      Math.abs(await page.evaluate(() => __carway.sound.musicVol) - 0.3) < 0.01);
    await page.evaluate(() => {
      const el = document.querySelector('#set-sfx');
      el.value = '45'; el.dispatchEvent(new Event('input', { bubbles: true }));
    });
    t('sound slider sets sfx volume',
      Math.abs(await page.evaluate(() => __carway.sound.sfxVol) - 0.45) < 0.01);
    // Mute toggle syncs everywhere.
    await page.click('#btn-mute-settings');
    const mute = await page.evaluate(() => ({
      muted: __carway.sound.muted,
      label: document.querySelector('#btn-mute-settings').textContent,
      hud: document.querySelector('#btn-mute').classList.contains('muted'),
    }));
    t('mute toggles + syncs HUD icon', mute.muted === true && /MUTED/.test(mute.label) && mute.hud, JSON.stringify(mute));
    await page.click('#btn-mute-settings'); // back on
    // Quality cycles and persists.
    const q0 = await page.evaluate(() => __carway.quality);
    await page.click('#btn-quality-settings');
    const q1 = await page.evaluate(() => ({
      q: __carway.quality,
      label: document.querySelector('#btn-quality-settings .quality-label').textContent,
      stored: localStorage.getItem('carway_quality'),
    }));
    t('quality cycles + persists', q1.q !== q0 && q1.label === q1.q.toUpperCase() && q1.stored === q1.q,
      JSON.stringify({ from: q0, ...q1 }));
    // Reset: single tap arms but wipes nothing; second tap wipes progress.
    await page.evaluate(() => {
      const g = window.__carway;
      g.save.data.coins = 777;
      g.save.data.cars = ['roadster', 'coupe']; g.save.data.car = 'coupe';
      g.save.data.upgrades.shield = 4;
      g.save._persist();
    });
    await page.click('#btn-reset');
    const armed = await page.evaluate(() => ({
      text: document.querySelector('#btn-reset').textContent,
      coins: __carway.save.data.coins,
    }));
    t('first reset tap only arms', /CONFIRM/.test(armed.text) && armed.coins === 777, JSON.stringify(armed));
    await page.click('#btn-reset');
    await page.waitForTimeout(300);
    const wiped = await page.evaluate(() => ({
      coins: __carway.save.data.coins,
      cars: __carway.save.data.cars,
      car: __carway.save.data.car,
      up: __carway.save.data.upgrades,
      quality: __carway.quality,
      musicVol: +__carway.sound.musicVol.toFixed(2),
    }));
    t('confirmed reset wipes progress', wiped.coins === 0 && wiped.cars.join() === 'roadster' &&
      wiped.car === 'roadster' && Object.values(wiped.up).every((v) => v === 1), JSON.stringify(wiped));
    t('reset keeps quality + volumes', wiped.musicVol === 0.3 && wiped.quality === q1.q, JSON.stringify(wiped));
    await page.click('#btn-settings-back');
    await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
    t('settings back returns to lobby', true);
    t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// --------------------------------------- gantry signs + logo billboards
console.log('— Gantry signs clear the view; logo billboards placed safely —');
{
  const { page, errors, ctx } = await freshPage();
  try {
    await page.waitForFunction(() => window.__carway.road.billboardTex !== null, null, { timeout: 15000 });
    const geo = await page.evaluate(() => {
      const g = window.__carway;
      const out = {
        boards: [], columns: [], arts: [], poles: [], groups: g.road.billboardGroups.length,
        texW: 0, texH: 0, sharedArt: true,
      };
      if (g.road.billboardTex && g.road.billboardTex.image) {
        // naturalWidth: bitmap size, independent of intro-screen layout state
        // (img.width reflects CSS display size while the intro is visible).
        const ti = g.road.billboardTex.image;
        out.texW = ti.naturalWidth || ti.width;
        out.texH = ti.naturalHeight || ti.height;
      }
      const artMat = g.road._bbArtMat;
      for (const seg of g.road.segments) {
        seg.traverse((o) => {
          if (!o.isMesh) return;
          if (o.userData.gantryBoard) out.boards.push(+o.position.y.toFixed(2));
          if (o.userData.gantryColumn) out.columns.push(+Math.abs(o.position.x).toFixed(2));
          if (o.userData.billboard === 'art') {
            if (o.material !== artMat) out.sharedArt = false;
            let yaw = 0, q = o.parent;
            while (q) { yaw += q.rotation.y || 0; q = q.parent; }
            out.arts.push(+yaw.toFixed(3));
          }
          if (o.userData.billboard === 'pole') {
            const gx = o.parent.position.x, th = o.parent.rotation.y || 0;
            out.poles.push(+Math.abs(gx + o.position.x * Math.cos(th) + o.position.z * Math.sin(th)).toFixed(2));
          }
        });
      }
      return out;
    });
    t('4 logo billboards built (2 plains x 2 sides)', geo.groups === 4, String(geo.groups));
    t('gantry boards ride above the camera (bottom 6.1 > 5.6)',
      geo.boards.length === 6 && Math.min(...geo.boards) - 0.8 > 5.6, JSON.stringify(geo.boards));
    t('gantry columns stand off the road (|x| 8.3)',
      geo.columns.length === 6 && Math.min(...geo.columns) > 7.5, JSON.stringify(geo.columns));
    t('billboard poles stay outside the rails (|x| > 7.5)',
      geo.poles.length === 8 && Math.min(...geo.poles) > 7.5, JSON.stringify(geo.poles));
    t('billboard art faces the player (+Z, yaw <= 0.12)',
      geo.arts.length === 4 && geo.arts.every((y) => Math.abs(y) <= 0.13), JSON.stringify(geo.arts));
    t('logo texture shared, square 512px (undistorted)',
      geo.sharedArt && geo.texW === 512 && geo.texH === 512,
      `${geo.texW}x${geo.texH} shared=${geo.sharedArt}`);
    // Real gameplay framing: drive a few seconds, burst-shoot the boards.
    await page.click('#btn-start');
    await page.waitForFunction(() => window.__carway.state === 'playing', null, { timeout: 10000 });
    await page.waitForFunction(() => window.__carway.distance > 40, null, { timeout: 60000 });
    await page.screenshot({ path: 'test/shot-billboard.png' });
    t('boards recycle with segments (no errors)', errors.length === 0, errors.join(' | ').slice(0, 200));
    t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// -------------------------------------------------------------- landscape
console.log('— Landscape orientation —');
{
  const { page, errors, ctx } = await freshPage({ width: 844, height: 390 });
  try {
    t('boots to lobby in landscape',
      await page.evaluate(() => __carway.state === 'menu' && __carway.lobby.visible));
    await page.click('#btn-start');
    await page.waitForFunction(() => window.__carway.state === 'playing', null, { timeout: 10000 });
    t('PLAY starts a run in landscape', true);
    await page.evaluate(() => { __carway.toMenu(); });
    await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
    await openNav(page);
    await page.click('#btn-garage');
    await page.waitForFunction(() => window.__carway.state === 'garage', null, { timeout: 5000 });
    t('garage opens in landscape', true);
    t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// ------------------------------------------------------------------ intro
console.log('— Brand intro: reveal, skip, once-per-session —');
{
  const { page, errors, ctx } = await freshPage({ width: 390, height: 844 }, URL.replace('?nointro=1', ''));
  try {
    t('intro overlay shows on fresh launch', await page.locator('#intro-screen').isVisible());
    t('intro plays the YF reveal animation',
      await page.evaluate(() => document.querySelector('#intro-screen').classList.contains('intro-run')));
    t('intro shows the YF logo asset',
      await page.evaluate(() => { const i = document.querySelector('#intro-logo'); return i && i.complete && i.naturalWidth > 0; }));
    await page.waitForTimeout(1200);
    await page.screenshot({ path: 'test/shot-intro.png' });
    await page.mouse.click(195, 422); // tap to skip
    await page.waitForFunction(() => document.querySelector('#intro-screen').classList.contains('hidden'), null, { timeout: 5000 });
    t('tap skips the intro', true);
    t('lobby live right after skip',
      await page.evaluate(() => __carway.state === 'menu' && !document.querySelector('#start-screen').classList.contains('hidden')));
    // Reload in the same tab: not a fresh launch → no intro.
    await page.reload({ waitUntil: 'networkidle' });
    await page.waitForFunction(() => window.__carway, null, { timeout: 20000 });
    await page.waitForTimeout(500);
    t('no intro repeat in the same session',
      await page.evaluate(() => document.querySelector('#intro-screen').classList.contains('hidden')));
    t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}


console.log('— Billboard bind: slow + flaky + failed logo fetch —');
{
  // Slow image (2.5 s): boot awaits pixels; boards correct from frame 1.
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.route('**/yf-logo.png*', (r) => setTimeout(() => r.continue(), 2500));
  try {
  await page.goto(URL, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 30000 });
  const slow = await page.evaluate(() => ({ tex: !!__carway.road.billboardTex,
    map: !!__carway.road._bbArtMat.map, white: __carway.road._bbArtMat.color.getHex() === 0xffffff }));
  t('slow logo still binds (boot awaits pixels)', slow.tex && slow.map && slow.white, JSON.stringify(slow));
  t('zero page/console errors on slow load', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('slow-load page finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}
{
  // Flaky image (first fetch fails, retry succeeds): the one retry heals.
  // (On standalone the data-URI never fails, so this passes trivially.)
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  let n = 0;
  await page.route('**/yf-logo.png*', (r) => { n += 1; if (n === 1) r.abort(); else r.continue(); });
  try {
  await page.goto(URL, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 30000 });
  await page.waitForFunction(() => !!window.__carway.road.billboardTex, null, { timeout: 30000 });
  const flaky = await page.evaluate(() => ({ tex: !!__carway.road.billboardTex,
    map: !!__carway.road._bbArtMat.map, white: __carway.road._bbArtMat.color.getHex() === 0xffffff,
    retried: !!__carway.road._bbRetried }));
  t('failed-then-ok fetch heals via the one retry', flaky.tex && flaky.map && flaky.white,
    JSON.stringify(flaky));
  const ours = errors.filter((e) => !/Failed to load resource|net::ERR/.test(e));
  t('no page errors from our code on flaky fetch', ours.length === 0, ours.join(' | ').slice(0, 300));
  } catch (e) { t('flaky-load page finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}
if (URL.includes('standalone')) {
  t('failed-fetch degrade n/a on standalone (inlined data-URI)', true);
} else {
  // Failed image: game boots and plays; boards degrade dark; no page errors.
  // (The browser itself logs the failed fetch — filtered, not ours.)
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.route('**/yf-logo.png*', (r) => r.abort());
  try {
  await page.goto(URL, { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 30000 });
  await page.click('#btn-start');
  await page.waitForFunction(() => window.__carway.state === 'playing' && window.__carway.distance > 5,
    null, { timeout: 60000 });
  const dead = await page.evaluate(() => ({ state: __carway.state,
    boards: __carway.road.billboardGroups.length, tex: !!__carway.road.billboardTex,
    retried: !!__carway.road._bbRetried }));
  const ours = errors.filter((e) => !/Failed to load resource|net::ERR/.test(e));
  t('game boots + plays with logo missing', dead.state === 'playing' && dead.boards === 4,
    JSON.stringify(dead));
  t('boards degrade dark after the retry gives up', dead.tex === false && dead.retried === true,
    JSON.stringify(dead));
  t('no page errors from our code on failed fetch', ours.length === 0, ours.join(' | ').slice(0, 300));
  } catch (e) { t('failed-fetch page finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed.`);
process.exit(fail ? 1 : 0);
