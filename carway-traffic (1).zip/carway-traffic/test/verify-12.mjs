// 12-point acceptance probe: fills gaps beyond the suites (positions, yellow,
// intro auto-end + sound wiring, back-button no-reset). Fails loudly.
import { chromium } from 'playwright';
let fail = 0;
const t = (name, cond, extra = '') => {
  console.log(`  ${cond ? '✅' : '❌'} ${name}${cond ? '' : ' ' + extra}`);
  if (!cond) fail++;
};
const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader'] });

// --- A: intro auto-end (no tap) + sound wiring on skip ---
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 20000 });
  const t0 = Date.now();
  await page.waitForFunction(() => document.querySelector('#intro-screen').classList.contains('hidden'),
    null, { timeout: 8000 });
  const dt = Date.now() - t0;
  t('intro auto-completes to the lobby (~2.8s, no tap)', dt < 7000, `${dt}ms`);
  t('auto-end: lobby interactive right after',
    await page.evaluate(() => __carway.state === 'menu' && !document.querySelector('#start-screen').classList.contains('hidden')));
  await ctx.close();
}
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('http://127.0.0.1:8080/index.html', { waitUntil: 'networkidle' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 20000 });
  await page.evaluate(() => {
    const s = window.__carway.sound;
    window.__sweepCalls = 0;
    const orig = s.introSweep.bind(s);
    s.introSweep = () => { window.__sweepCalls++; orig(); };
  });
  // Tap the moment the game exists (intro confirmed visible): a fixed 900 ms
  // wait decouples from the intro clock — under sandbox load the intro can
  // auto-end first and the tap lands on the lobby (no skip, no sting).
  const introVisible = await page.evaluate(() => !document.querySelector('#intro-screen').classList.contains('hidden'));
  t('intro still playing at tap time (skip test valid)', introVisible);
  if (introVisible) await page.mouse.click(195, 422); // skip tap = real gesture
  await page.waitForFunction(() => document.querySelector('#intro-screen').classList.contains('hidden'),
    null, { timeout: 8000 });
  const snd = await page.evaluate(() => ({
    calls: window.__sweepCalls, ctx: !!__carway.sound.ctx,
    running: __carway.sound.ctx && __carway.sound.ctx.state,
    muted: __carway.sound.muted,
  }));
  t('skip tap plays the intro sting (wired + unlocked)', snd.calls === 1 && snd.ctx && snd.running === 'running', JSON.stringify(snd));
  t('sound starts unmuted (settings respected)', snd.muted === false);
  t('no errors across intro paths', errors.length === 0, errors.join(' | ').slice(0, 200));
  await ctx.close();
}

// --- B: lobby geometry + yellow paint + back-button no-reset ---
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('http://127.0.0.1:8080/index.html?nointro=1', { waitUntil: 'networkidle' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 20000 });
  const geo = await page.evaluate(() => {
    const r = (id) => { const b = document.getElementById(id).getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height }; };
    return { play: r('btn-start'), gear: r('btn-settings'), nav: r('btn-nav'), best: r('best-line') };
  });
  t('PLAY bottom-center + touch-sized', geo.play.y > 550 && Math.abs(geo.play.x + geo.play.w / 2 - 195) < 40 && geo.play.w > 200 && geo.play.h > 50, JSON.stringify(geo.play));
  t('settings gear top-right', geo.gear.y < 120 && geo.gear.x > 390 - 120, JSON.stringify(geo.gear));
  t('nav toggle top-left', geo.nav.y < 120 && geo.nav.x < 120, JSON.stringify(geo.nav));
  t('best chip top-center', geo.best.y < 160 && Math.abs(geo.best.x + geo.best.w / 2 - 195) < 120, JSON.stringify(geo.best));
  await page.screenshot({ path: 'test/shot-lobby.png' });
  // Yellow paint: visible row, real price, buys + repaints live.
  await page.evaluate(() => { __carway.save.data.coins = 500; __carway.save._persist(); __carway.refreshMenuUI(); });
  await page.click('#btn-nav');
  await page.waitForFunction(() => document.querySelector('#nav-drawer').getBoundingClientRect().left >= -0.5, null, { timeout: 15000 });
  await page.click('#btn-garage');
  await page.waitForFunction(() => window.__carway.state === 'garage', null, { timeout: 5000 });
  const yellow = await page.evaluate(() => {
    const row = [...document.querySelectorAll('#paint-list .paint-row')].find((r) => r.textContent.includes('Racing Yellow'));
    return row ? { visible: row.offsetParent !== null, btn: row.querySelector('button').textContent } : null;
  });
  t('yellow row visible with real 250 price', !!yellow && yellow.visible && yellow.btn.includes('250'), JSON.stringify(yellow));
  await page.locator('.paint-row', { hasText: 'Racing Yellow' }).locator('button').click();
  const ys = await page.evaluate(() => ({
    coins: __carway.save.data.coins, paint: __carway.save.data.paint,
    hex: __carway.player.paintMats[0].color.getHex(),
  }));
  t('yellow buys for 250 + repaints live', ys.coins === 250 && ys.paint === 'yellow' && ys.hex === 0xf7c500, JSON.stringify(ys));
  // Back button: top-left, returns without resetting anything.
  const back = await page.evaluate(() => { const b = document.getElementById('btn-garage-back').getBoundingClientRect(); return { x: b.x, y: b.y, w: b.width, h: b.height }; });
  const panel = await page.evaluate(() => document.querySelector('.garage-panel').getBoundingClientRect().toJSON());
  t('garage back is top-left + touch-sized', back.x - panel.x < 60 && back.y - panel.y < 80 && back.w >= 40 && back.h >= 40, JSON.stringify(back));
  await page.click('#btn-garage-back');
  await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
  const kept = await page.evaluate(() => ({
    coins: __carway.save.data.coins, paint: __carway.save.data.paint,
    hex: __carway.player.paintMats[0].color.getHex(),
  }));
  t('back keeps coins/paint/live 3D (no reset)', kept.coins === 250 && kept.paint === 'yellow' && kept.hex === 0xf7c500, JSON.stringify(kept));
  // Missions back button exists + works too.
  await page.click('#btn-nav');
  await page.waitForFunction(() => document.querySelector('#nav-drawer').getBoundingClientRect().left >= -0.5, null, { timeout: 15000 });
  await page.click('#btn-missions');
  await page.waitForFunction(() => window.__carway.state === 'missions', null, { timeout: 5000 });
  await page.click('#btn-missions-back');
  await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
  t('missions back returns to lobby', true);
  t('no errors in acceptance paths', errors.length === 0, errors.join(' | ').slice(0, 200));
  await ctx.close();
}
await browser.close();
console.log(fail ? `\nVERIFY: ${fail} FAILED` : '\nVERIFY: ALL PASS');
process.exit(fail ? 1 : 0);
