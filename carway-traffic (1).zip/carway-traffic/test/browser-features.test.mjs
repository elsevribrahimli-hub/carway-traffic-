// CARWAY TRAFFIC — Browser feature tests: shield, 2x coins, police chase,
// garage cars. Run: `node test/browser-features.test.mjs` (game at :8080).
// All waits poll GAME state, so results are deterministic under SwiftShader.
import { chromium } from 'playwright';

const URL = process.env.CARWAY_URL || 'http://127.0.0.1:8080/index.html?nointro=1';
let pass = 0, fail = 0;
const t = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else { fail++; console.log(`  ❌ ${name} ${extra}`); }
};

const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader'] });

// Fresh browser context per scenario = fresh localStorage profile.
// Open the nav drawer and wait until its slide transition fully settles
// (sandbox SwiftShader frames can stretch CSS transitions over seconds).
async function openNav(page) {
  await page.click('#btn-nav');
  await page.waitForFunction(
    () => document.querySelector('#nav-drawer').getBoundingClientRect().left >= -0.5,
    null, { timeout: 15000 });
}

async function freshPage(w = 390, h = 844) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  await page.goto(URL, { waitUntil: 'networkidle' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 20000 });
  return { page, errors, ctx };
}

async function startRun(page) {
  await page.click('#btn-start');
  await page.waitForFunction(() => window.__carway.state === 'playing' && window.__carway.distance > 5,
    null, { timeout: 60000 });
}

// Park every obstacle (rows only spawn past 60m, but be airtight anyway).
async function clearTraffic(page) {
  await page.evaluate(() => {
    const g = window.__carway;
    for (const c of g.traffic.cars) { c.active = false; c.group.visible = false; }
    for (const h of g.traffic.hazards) { h.active = false; h.group.visible = false; }
  });
}

// Place a live traffic car at (player.x + dx, playerZ + dz). Returns its kind.
async function teleportObstacle(page, dx, dz) {
  return page.evaluate(({ dx, dz }) => {
    const g = window.__carway;
    const c = g.traffic.cars.find((c) => !c.active) || g.traffic.cars[0];
    c.active = true; c._hitMark = false; c.jumpedOver = false;
    c.group.visible = true;
    c.group.position.set(g.player.x + dx, 0, dz);
    return c.kind;
  }, { dx, dz });
}

// Place a live traffic car of a given body at (player.x + dx, playerZ + dz).
async function teleportBody(page, body, dx, dz) {
  return page.evaluate(({ body, dx, dz }) => {
    const g = window.__carway;
    const c = g.traffic.cars.find((c) => !c.active && c.body === body)
      || g.traffic.cars.find((c) => c.body === body);
    c.active = true; c._hitMark = false; c.jumpedOver = false; c.counted = false;
    c.group.visible = true;
    c.group.position.set(g.player.x + dx, 0, dz);
    return { kind: c.kind, wid: c.wid, len: c.len };
  }, { body, dx, dz });
}

// Spawn a pickup orb of a forced type right on top of the player.
async function dropPickup(page, type) {
  await page.evaluate((type) => {
    const g = window.__carway;
    g.pickups._spawn();
    const p = g.pickups.items.find((p) => p.active);
    p.type = type;
    g.pickups._showType(p); // exclusive visual (shield / 2x / magnet)
    p.root.position.set(g.player.x, 0, 0);
  }, type);
}

// ---------------------------------------------------------------- rear-end
console.log('— Rear collision = instant game over (CRASH!) —');
{
  const { page, errors, ctx } = await freshPage();
  try {
  await startRun(page);
  await clearTraffic(page);
  await teleportObstacle(page, 0, -2.9); // centered rear-ender entry
  await page.waitForFunction(() => window.__carway.state === 'over', null, { timeout: 45000 });
  await page.waitForFunction(() => !document.getElementById('gameover-screen').classList.contains('hidden'),
    null, { timeout: 45000 });
  const s = await page.evaluate(() => ({
    title: document.getElementById('crash-title').textContent,
    banked: window.__carway.runBanked,
    chase: window.__carway.penalty.chase,
    used: window.__carway.penalty.used,
  }));
  t('rear-ender ends the run', true);
  t('title stays CRASH!', s.title === 'CRASH!', s.title);
  t('no police chase on a rear-ender', s.chase === false && s.used === false);
  t('game-over screen appears', true);
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// ------------------------------------------------- side scrape -> chase
console.log('— Chase cycle: scrape → escape → re-chase → caught mid-chase —');
{
  const { page, errors, ctx } = await freshPage();
  try {
  await startRun(page);
  await clearTraffic(page);
  // Sterile: live pickup orbs during the long escape could grant a shield
  // charge that absorbs the re-chase contact (real game rule, test noise).
  await page.evaluate(() => {
    const g = window.__carway;
    g.pickups.nextGap = 1e12;
    for (const p of g.pickups.items) { p.active = false; p.root.visible = false; }
  });
  await teleportObstacle(page, 1.35, 0.3); // side-scrape entry
  await page.waitForFunction(() => window.__carway.penalty.chase === true, null, { timeout: 45000 });
  const c = await page.evaluate(() => ({
    state: window.__carway.state,
    police: window.__carway.police.active,
    siren: !!window.__carway.sound.sirenOsc,
    banner: !document.getElementById('chase-banner').classList.contains('hidden'),
    bannerTxt: document.getElementById('chase-banner').textContent,
  }));
  t('first side scrape does NOT end the run', c.state === 'playing', c.state);
  t('police car spawns behind', c.police === true);
  t('siren starts (mutable via master mute)', c.siren === true);
  t('chase banner shows one-chance-left countdown',
    c.banner && /ONE CHANCE LEFT/.test(c.bannerTxt), c.bannerTxt);
  // Survive the chase: keep the road clear while the timer runs out.
  await page.waitForFunction(() => {
    const g = window.__carway;
    for (const c of g.traffic.cars) { c.active = false; c.group.visible = false; }
    return g.penalty.chase === false;
  }, null, { timeout: 90000 });
  await page.waitForFunction(() => window.__carway.police.active === false, null, { timeout: 30000 });
  const a = await page.evaluate(() => ({
    state: window.__carway.state,
    used: window.__carway.penalty.used,
    siren: window.__carway.sound.sirenOsc,
    banner: document.getElementById('chase-banner').classList.contains('hidden'),
  }));
  t('surviving the timer ends the chase, run continues', a.state === 'playing');
  t('escape restores the second chance (used reset)', a.used === false);
  t('siren stops + banner hides', a.siren == null && a.banner === true);
  const esc = await page.evaluate(() => ({
    chase: __carway.penalty.chase, chaseT: +__carway.penalty.chaseT.toFixed(2),
    police: __carway.police.active, leaving: __carway.police.leaving,
  }));
  t('escape cleans timers + police flags', esc.chase === false && esc.chaseT <= 0 && !esc.police && !esc.leaving,
    JSON.stringify(esc));
  // Escape → NORMAL: a new side scrape starts a NEW chase (the bug fix).
  await clearTraffic(page);
  await page.evaluate(() => { window.__carway.shieldGrace = 0; });
  await teleportObstacle(page, 1.35, 0.3); // fresh side-scrape entry
  await page.waitForFunction(() => window.__carway.penalty.chase === true, null, { timeout: 45000 });
  const c2 = await page.evaluate(() => ({
    state: __carway.state, used: __carway.penalty.used,
    chaseT: +__carway.penalty.chaseT.toFixed(2), police: __carway.police.active,
  }));
  t('second side scrape after escape starts a NEW chase',
    c2.state === 'playing' && c2.used && c2.police, JSON.stringify(c2));
  t('new chase runs a fresh full timer', c2.chaseT > 6 && c2.chaseT <= 8, String(c2.chaseT));
  // Same-car refire guard: re-pinning the trigger car onto the player must
  // NOT end the run (one collision = one event, hitMark holds).
  await page.evaluate(() => {
    const g = window.__carway;
    const car = g.traffic.cars.find((c) => c.active);
    window.__trigCar = g.traffic.cars.indexOf(car);
    car.group.position.set(g.player.x + 1.35, 0, 0.3);
  });
  for (let i = 0; i < 5; i++) {
    await page.waitForTimeout(200);
    await page.evaluate(() => {
      const g = window.__carway;
      g.traffic.cars[window.__trigCar].group.position.set(g.player.x + 1.35, 0, 0.3);
    });
  }
  const refire = await page.evaluate(() => ({ state: __carway.state, chase: __carway.penalty.chase }));
  t('same collision never refires (no double event)',
    refire.state === 'playing' && refire.chase === true, JSON.stringify(refire));
  // Fresh side scrape DURING the chase: caught immediately (+ coins bank).
  await page.evaluate(() => { window.__carway.runCoins = 5; });
  await teleportObstacle(page, 1.35, 0.3);
  await page.waitForFunction(() => window.__carway.state === 'over', null, { timeout: 45000 });
  // The title is set when the game-over screen appears (~1.2s game-time later).
  await page.waitForFunction(() => !document.getElementById('gameover-screen').classList.contains('hidden'),
    null, { timeout: 45000 });
  const title = await page.evaluate(() => document.getElementById('crash-title').textContent);
  t('side scrape mid-chase ends the run as CAUGHT BY THE POLICE!', title === 'CAUGHT BY THE POLICE!', title);
  // Coins text populates with the game-over screen; poll for it instead of a
  // single-shot read (under sandbox load the text can lag screen-visible).
  let overCoins = '';
  try {
    await page.waitForFunction(() => document.getElementById('over-coins').textContent === '+5',
      null, { timeout: 30000 });
    overCoins = '+5';
  } catch (e) { overCoins = await page.locator('#over-coins').textContent(); }
  t('caught run still banks earned coins', overCoins === '+5', overCoins);
  // Fresh run resets the penalty.
  await page.click('#btn-restart');
  await page.waitForFunction(() => window.__carway.state === 'playing' && window.__carway.distance > 3,
    null, { timeout: 60000 });
  const f = await page.evaluate(() => ({
    used: window.__carway.penalty.used, chase: window.__carway.penalty.chase,
    chaseT: window.__carway.penalty.chaseT,
    charges: window.__carway.shield.charges, police: window.__carway.police.active,
  }));
  t('restart fully resets chase/shield/police',
    !f.used && !f.chase && f.chaseT === 0 && f.charges === 0 && !f.police, JSON.stringify(f));
  // Rear-ender on the fresh run: instant CRASH (existing rear rule kept).
  await clearTraffic(page);
  await teleportObstacle(page, 0, -2.9);
  await page.waitForFunction(() => window.__carway.state === 'over', null, { timeout: 45000 });
  await page.waitForFunction(() => !document.getElementById('gameover-screen').classList.contains('hidden'),
    null, { timeout: 45000 });
  const title2 = await page.evaluate(() => document.getElementById('crash-title').textContent);
  t('rear-ender stays instant CRASH (no chase)', title2 === 'CRASH!', title2);
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// ------------------------------------------------------------------ shield
console.log('— Shield absorbs one hit, then breaks (single-use) —');
{
  const { page, errors, ctx } = await freshPage();
  try {
  await startRun(page);
  await clearTraffic(page);
  await dropPickup(page, 'shield');
  await page.waitForFunction(() => window.__carway.shield.charges === 1, null, { timeout: 45000 });
  const b = await page.evaluate(() => ({
    shell: window.__carway.player.shieldMesh.visible,
    badge: !!document.querySelector('#hud-badges .badge-shield'),
    badgeTxt: (document.querySelector('#hud-badges .badge-shield') || {}).textContent,
  }));
  t('shield orb grants one charge', true);
  t('blue shell visible around the car', b.shell === true);
  t('HUD shows shield countdown badge', b.badge && /🛡/.test(b.badgeTxt || ''), b.badgeTxt);
  await teleportObstacle(page, 0, -2.9); // would-be fatal rear-ender
  await page.waitForFunction(() => window.__carway.shield.charges === 0, null, { timeout: 45000 });
  const s = await page.evaluate(() => ({
    state: window.__carway.state,
    used: window.__carway.penalty.used,
    grace: window.__carway.shieldGrace,
    shell: window.__carway.player.shieldMesh.visible,
    badge: !!document.querySelector('#hud-badges .badge-shield'),
  }));
  t('shield absorbs the hit: run continues', s.state === 'playing', s.state);
  t('absorbed hit triggers NO police penalty', s.used === false);
  t('brief grace follows the break', s.grace > 0, String(s.grace));
  t('shell + badge clear after absorbing', s.shell === false && s.badge === false);
  // Single-use: the next hit (after grace) is fatal, still no free chase.
  await page.evaluate(() => { window.__carway.shieldGrace = 0; });
  await clearTraffic(page);
  await teleportObstacle(page, 0, -2.9);
  await page.waitForFunction(() => window.__carway.state === 'over', null, { timeout: 45000 });
  await page.waitForFunction(() => !document.getElementById('gameover-screen').classList.contains('hidden'),
    null, { timeout: 45000 });
  const title = await page.evaluate(() => document.getElementById('crash-title').textContent);
  t('next hit after shield = normal CRASH!', title === 'CRASH!', title);
  // Expiry path: a charge that is never hit still times out.
  await page.click('#btn-restart');
  await page.waitForFunction(() => window.__carway.state === 'playing' && window.__carway.distance > 3,
    null, { timeout: 60000 });
  await clearTraffic(page);
  await dropPickup(page, 'shield');
  await page.waitForFunction(() => window.__carway.shield.charges === 1, null, { timeout: 45000 });
  await page.evaluate(() => { window.__carway.shield.timeLeft = 0.3; });
  await page.waitForFunction(() => window.__carway.shield.charges === 0 &&
    !window.__carway.player.shieldMesh.visible, null, { timeout: 45000 });
  t('unused shield expires cleanly', true);
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 200));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// ----------------------------------------------------------------- 2x coins
console.log('— 2x coins double awards exactly once —');
{
  const { page, errors, ctx } = await freshPage();
  try {
  await startRun(page);
  await clearTraffic(page);
  await dropPickup(page, 'coin2x');
  await page.waitForFunction(() => window.__carway.coin2x.timeLeft > 0, null, { timeout: 45000 });
  const badge = await page.evaluate(() =>
    (document.querySelector('#hud-badges .badge-coin2x') || {}).textContent);
  t('HUD shows 2x countdown badge', /2X/.test(badge || ''), badge);
  const math = await page.evaluate(() => {
    const g = window.__carway;
    const c0 = g.runCoins;
    g.awardCoins(1);
    const c1 = g.runCoins;
    g.awardCoins(2);
    const c2 = g.runCoins;
    return { c0, c1, c2 };
  });
  t('single coin awards +2 while active', math.c1 - math.c0 === 2, JSON.stringify(math));
  t('bundle of 2 awards +4 (doubled once, not twice)', math.c2 - math.c1 === 4, JSON.stringify(math));
  await page.evaluate(() => { window.__carway.coin2x.timeLeft = 0.2; });
  await page.waitForFunction(() => window.__carway.coin2x.timeLeft <= 0 &&
    !document.querySelector('#hud-badges .badge-coin2x'), null, { timeout: 45000 });
  const after = await page.evaluate(() => {
    const g = window.__carway;
    const c0 = g.runCoins;
    g.awardCoins(1);
    return g.runCoins - c0;
  });
  t('after expiry awards return to +1 and badge clears', after === 1, String(after));
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

// -------------------------------------------------------------- garage cars
console.log('— Garage cars: buy, select, persist —');
{
  const { page, errors, ctx } = await freshPage();
  try {
  await openNav(page);
  await page.click('#btn-garage');
  await page.click('#btn-garage-tab-cars');
  await page.waitForFunction(() => window.__carway.state === 'garage', null, { timeout: 45000 });
  const rows = await page.evaluate(() => document.querySelectorAll('#car-list .paint-row').length);
  t('garage lists 4 cars', rows === 4, String(rows));
  await page.evaluate(() => {
    const g = window.__carway;
    g.save.data.coins = 2000;
    g.ui.refreshGarage(g.save.data);
  });
  const buyBtn = (n) => `#car-list .paint-row:nth-child(${n}) button`;
  await page.click(buyBtn(4)); // Apex Supercar, 1200
  await page.waitForFunction(() => window.__carway.player.carBody === 'supercar', null, { timeout: 45000 });
  const s1 = await page.evaluate(() => ({
    car: window.__carway.save.data.car, coins: window.__carway.save.data.coins,
    btn: document.querySelector('#car-list .paint-row:nth-child(4) button').textContent,
  }));
  t('buying supercar deducts 1200 + selects it', s1.car === 'supercar' && s1.coins === 800, JSON.stringify(s1));
  t('bought car shows SELECTED', s1.btn === 'SELECTED', s1.btn);
  await page.click(buyBtn(2)); // Velocity Coupe, 600
  await page.waitForFunction(() => window.__carway.player.carBody === 'coupe', null, { timeout: 45000 });
  const s2 = await page.evaluate(() => ({
    car: window.__carway.save.data.car, coins: window.__carway.save.data.coins,
  }));
  t('second purchase switches selection', s2.car === 'coupe' && s2.coins === 200, JSON.stringify(s2));
  await page.reload({ waitUntil: 'networkidle' });
  await page.waitForFunction(() => window.__carway, null, { timeout: 20000 });
  const s3 = await page.evaluate(() => ({
    car: window.__carway.save.data.car, body: window.__carway.player.carBody,
    coins: window.__carway.save.data.coins,
  }));
  t('car + coins persist across reload', s3.car === 'coupe' && s3.body === 'coupe' && s3.coins === 200, JSON.stringify(s3));
  // Poor purchase rejected without deduction.
  await openNav(page);
  await page.click('#btn-garage');
  await page.click('#btn-garage-tab-cars');
  await page.waitForFunction(() => window.__carway.state === 'garage', null, { timeout: 45000 });
  await page.evaluate(() => {
    const g = window.__carway;
    g.save.data.coins = 0;
    g.ui.refreshGarage(g.save.data);
  });
  await page.click(buyBtn(3)); // Volt Sedan, 900 — cannot afford
  await page.waitForTimeout(400);
  const s4 = await page.evaluate(() => ({
    car: window.__carway.save.data.car, coins: window.__carway.save.data.coins,
  }));
  t('poor purchase rejected, selection kept', s4.car === 'coupe' && s4.coins === 0, JSON.stringify(s4));
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}


console.log('— Fair-spawn soak: steering-only AI to full difficulty (2500m) —');
{
  // Small viewport: SwiftShader fps is pixel-bound; the soak needs game-time,
  // not pixels (AI steers from state, gameplay/rendering untouched).
  const { page, errors, ctx } = await freshPage(240, 480);
  try {
  await startRun(page);
  // Low render tier for soak speed (same tier real low-end Android uses;
  // physics/spawning/collisions are tier-independent).
  await page.evaluate(() => window.__carway.setQuality('low'));
  let samples = 0, violations = 0, maxClusters = 0, everChase = false, everShield = 0;
  let last = null;
  const t0 = Date.now();
  while (Date.now() - t0 < 300000) {
    const s = await page.evaluate(() => {
      const g = window.__carway;
      // Sterile run: no pickups — a shield absorb or chase would mask a wall.
      g.pickups.nextGap = 1e12;
      for (const p of g.pickups.items) { p.active = false; p.root.visible = false; }
      if (g.state !== 'playing') return { over: true, dist: g.distance, chase: g.penalty.chase };
      const au = g.traffic.auditFairness(g.speed, g.distance);
      const cur = g.player.laneIndex;
      // Nearest encounter clusters within a 60 m lookahead (nearest first).
      const cars = g.traffic.cars.filter((c) => c.active && c.group.position.z > -60 && c.group.position.z < 2)
        .map((c) => ({ lane: c.lane, z: c.group.position.z }));
      cars.sort((a, b) => b.z - a.z);
      const clusters = [];
      for (const c of cars) {
        const lastC = clusters[clusters.length - 1];
        if (lastC && Math.abs(c.z - lastC.z) < 12) lastC.blocked.add(c.lane);
        else clusters.push({ z: c.z, blocked: new Set([c.lane]) });
      }
      // Score lanes: must be free in the nearest cluster; prefer free (or
      // adjacent-to-free) in the second so escapes chain; prefer near.
      let target = cur;
      if (clusters.length) {
        const free1 = [0, 1, 2].filter((l) => !clusters[0].blocked.has(l));
        const free2 = clusters[1] ? [0, 1, 2].filter((l) => !clusters[1].blocked.has(l)) : [0, 1, 2];
        let best = -1e9;
        for (const l of [0, 1, 2]) {
          let sc = free1.includes(l) ? 0 : -100;
          sc += free2.includes(l) ? 0 : -Math.min(...free2.map((f) => Math.abs(f - l)));
          sc -= Math.abs(l - cur) * 0.1;
          if (sc > best) { best = sc; target = l; }
        }
      }
      return { over: false, dist: g.distance, viol: au.violations.length, clusters: au.clusters,
        steer: Math.sign(target - cur), chase: g.penalty.chase, shield: g.player.shieldCharges };
    });
    last = s;
    if (s.over) break;
    samples++;
    violations += s.viol;
    if (s.clusters > maxClusters) maxClusters = s.clusters;
    if (s.chase) everChase = true;
    if (s.shield > 0) everShield = s.shield;
    if (s.dist >= 2500) break;
    if (s.steer !== 0) await page.keyboard.press(s.steer < 0 ? 'ArrowLeft' : 'ArrowRight');
    await page.waitForTimeout(300);
  }
  const dens = await page.evaluate(() => ({ cars: __carway.traffic.carsSpawned,
    rows: __carway.traffic.rowsSpawned, delayed: __carway.traffic.rowsDelayed,
    retries: __carway.traffic._validatorRetries, dist: Math.round(__carway.distance) }));
  t('soak reached full difficulty on steering alone (no jump/nitro)',
    !!last && !last.over && last.dist >= 2500, JSON.stringify(last && { dist: Math.round(last.dist), over: last.over }));
  t('zero fairness violations across soak samples', violations === 0, `samples=${samples} violations=${violations}`);
  t('soak met real traffic (non-empty road)', dens.rows >= 15 && dens.cars >= 20 && samples >= 100,
    `rows=${dens.rows} cars=${dens.cars} samples=${samples} maxClusters=${maxClusters}`);
  t('soak traffic stayed dense (low delays, full rows)', dens.delayed / Math.max(1, dens.rows) < 0.25
    && dens.cars / Math.max(1, dens.rows) >= 1.0 && dens.cars / Math.max(1, dens.dist) >= 0.02, JSON.stringify(dens));
  t('AI never scraped (no chase) and never shielded — pure steering', !everChase && everShield === 0,
    `chase=${everChase} shield=${everShield}`);
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}


console.log('— Side-collision physics: contact, push-out, lane return —');
{
  const { page, errors, ctx } = await freshPage();
  try {
  await startRun(page);
  await clearTraffic(page);
  // Sterile: no shield pickups that could mask a contact.
  await page.evaluate(() => { window.__carway.pickups.nextGap = 1e12; });
  await page.evaluate(() => {
    window.__scrapeCalls = 0; window.__crashCalls = 0;
    const s = window.__carway.sound;
    const oS = s.scrape.bind(s), oC = s.crash.bind(s);
    s.scrape = () => { window.__scrapeCalls++; oS(); };
    s.crash = () => { window.__crashCalls++; oC(); };
  });
  // F: NEAR MISS — car alongside but clear (dx 1.6 > maxDx 1.44).
  await teleportObstacle(page, 1.6, -1.0);
  let alongside = false;
  for (let i = 0; i < 12; i++) {
    const s = await page.evaluate(() => {
      const g = window.__carway;
      const c = g.traffic.cars.find((c) => c.active);
      return { z: c ? c.group.position.z : 99, chase: g.penalty.chase,
        state: g.state, px: g.player.x };
    });
    if (Math.abs(s.z) < 3) alongside = true;
    if (s.z > 8 || s.chase || s.state !== 'playing') break;
    await page.waitForTimeout(250);
  }
  const f = await page.evaluate(() => ({ chase: __carway.penalty.chase,
    state: __carway.state, px: +__carway.player.x.toFixed(3) }));
  t('near miss alongside triggers no chase', alongside && !f.chase && f.state === 'playing',
    `alongside=${alongside} chase=${f.chase}`);
  t('no false push without overlap (x untouched)', Math.abs(f.px) < 0.01, `px=${f.px}`);
  const fSnd = await page.evaluate(() => ({ scrape: window.__scrapeCalls, crash: window.__crashCalls }));
  t('near miss plays no impact sound', fSnd.scrape === 0 && fSnd.crash === 0, JSON.stringify(fSnd));
  // A+B: REAL lane change into a posed NPC (adjacent lane, just ahead).
  await clearTraffic(page);
  await teleportObstacle(page, 3.2, -2.0);
  await page.evaluate(() => { __carway.traffic.cars.find((c) => c.active).speed = 10; });
  await page.keyboard.press('ArrowRight'); // steer into the NPC's lane
  await page.waitForFunction(() => window.__carway.penalty.chase === true, null, { timeout: 45000 });
  const a = await page.evaluate(() => {
    const g = window.__carway;
    const c = g.traffic.cars.find((c) => c.active);
    return { state: g.state, lane: g.player.laneIndex, px: +g.player.x.toFixed(2),
      ox: c ? +c.group.position.x.toFixed(2) : -99,
      dx: c ? +Math.abs(g.player.x - c.group.position.x).toFixed(3) : -1,
      wid: c ? c.wid : 2 };
  });
  const aMaxDx = (2 + a.wid) / 2 * 0.72; // real per-car boundary (bodies vary)
  t('side swipe triggers the chase (event preserved)', a.state === 'playing', a.state);
  t('player pushed out of the NPC (no pass-through)', a.dx >= aMaxDx - 0.01,
    `dx=${a.dx} px=${a.px} maxDx=${aMaxDx.toFixed(3)}`);
  t('lane target reverts to the origin lane', a.lane === 1, `lane=${a.lane}`);
  t('player glides home, not teleported', a.px > 0.3 && a.px <= a.ox - aMaxDx + 0.05, `px=${a.px}`);
  const aSnd = await page.evaluate(() => ({ scrape: window.__scrapeCalls, crash: window.__crashCalls }));
  t('side scrape plays the impact thump once', aSnd.scrape === 1 && aSnd.crash === 0, JSON.stringify(aSnd));
  // C: GRIND — re-pin the same car alongside 4x (frozen z: speed = player).
  const grinds = [];
  for (let i = 0; i < 4; i++) {
    await page.evaluate(() => {
      const g = window.__carway;
      const c = g.traffic.cars.find((c) => c.active);
      c.speed = g.speed; // freeze z-gap: pure lateral grind
      c.group.position.set(g.player.x + 1.35, 0, 0.3);
    });
    // Wait for a game frame to process the pin (distance advances past the
    // post-pin baseline), then the blocking must hold in the sample.
    const d0 = await page.evaluate(() => window.__carway.distance);
    await page.waitForFunction((d) => window.__carway.distance > d, d0, { timeout: 30000 });
    grinds.push(await page.evaluate(() => {
      const g = window.__carway;
      const c = g.traffic.cars.find((c) => c.active);
      return { dx: +Math.abs(g.player.x - c.group.position.x).toFixed(3),
        wid: c.wid, state: g.state, chase: g.penalty.chase };
    }));
  }
  t('grinding never enters the NPC (blocking holds)',
    grinds.every((s) => s.dx >= (2 + s.wid) / 2 * 0.72 - 0.01),
    JSON.stringify(grinds.map((s) => s.dx)));
  t('grind fires no new event (run continues, chase unchanged)',
    grinds.every((s) => s.state === 'playing' && s.chase === true));
  const gSnd = await page.evaluate(() => ({ scrape: window.__scrapeCalls, crash: window.__crashCalls }));
  t('grinding replays no thump (one event = one sound)', gSnd.scrape === 1 && gSnd.crash === 0,
    JSON.stringify(gSnd));
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}
{
  // Contact-path NPC wobble: set on scrape, decays to exactly zero.
  const { page, errors, ctx } = await freshPage();
  try {
  await startRun(page);
  await clearTraffic(page);
  await page.evaluate(() => { window.__carway.pickups.nextGap = 1e12; });
  await teleportObstacle(page, 1.35, 0.3); // instant side contact
  await page.waitForFunction(() => window.__carway.penalty.chase === true, null, { timeout: 45000 });
  const b = await page.evaluate(() => {
    const g = window.__carway;
    const c = g.traffic.cars.find((c) => c.active);
    return { lane: g.player.laneIndex,
      dx: c ? +Math.abs(g.player.x - c.group.position.x).toFixed(3) : -1,
      wid: c ? c.wid : 2 };
  });
  t('contact separates + reverts lane', b.dx >= (2 + b.wid) / 2 * 0.72 - 0.01 && b.lane === 0,
    JSON.stringify(b));
  await page.waitForFunction(() => {
    const g = window.__carway;
    const c = g.traffic.cars.find((c) => c.active);
    return c && ((c._scrapeWob || 0) !== 0 || c.group.rotation.z !== 0);
  }, null, { timeout: 8000 });
  t('scrape sets the NPC wobble reply', true);
  await page.waitForFunction(() => {
    const g = window.__carway;
    const c = g.traffic.cars.find((c) => c.active);
    return c && (c._scrapeWob || 0) === 0 && c.group.rotation.z === 0;
  }, null, { timeout: 40000 });
  t('wobble decays to exactly zero (no stuck tilt)', true);
  // Rear impact on the same run: crash() covers game-over audio (no scrape).
  await page.evaluate(() => {
    window.__scrapeCalls = 0; window.__crashCalls = 0;
    const s = window.__carway.sound;
    const oS = s.scrape.bind(s), oC = s.crash.bind(s);
    s.scrape = () => { window.__scrapeCalls++; oS(); };
    s.crash = () => { window.__crashCalls++; oC(); };
  });
  await clearTraffic(page);
  await teleportObstacle(page, 0, -2.9);
  await page.waitForFunction(() => window.__carway.state === 'over', null, { timeout: 45000 });
  const rSnd = await page.evaluate(() => ({ scrape: window.__scrapeCalls, crash: window.__crashCalls }));
  t('rear impact plays crash(), not the side thump', rSnd.crash === 1 && rSnd.scrape === 0,
    JSON.stringify(rSnd));
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}
{
  // D: HIGH SPEED — side contact at max cruise (55 m/s), no tunneling.
  const { page, errors, ctx } = await freshPage();
  try {
  await startRun(page);
  await clearTraffic(page);
  await page.evaluate(() => { window.__carway.pickups.nextGap = 1e12; window.__carway.distance = 2600; });
  await teleportObstacle(page, 3.2, -4.0);
  await page.evaluate(() => { __carway.traffic.cars.find((c) => c.active).speed = 25; });
  await page.keyboard.press('ArrowRight');
  await page.waitForFunction(() => window.__carway.penalty.chase === true, null, { timeout: 45000 });
  const d = await page.evaluate(() => {
    const g = window.__carway;
    const c = g.traffic.cars.find((c) => c.active);
    return { state: g.state, lane: g.player.laneIndex, px: +g.player.x.toFixed(2),
      ox: c ? +c.group.position.x.toFixed(2) : -99, wid: c ? c.wid : 2,
      speed: Math.round(g.speed), dx: c ? +Math.abs(g.player.x - c.group.position.x).toFixed(3) : -1 };
  });
  t('high-speed side contact still detected (no tunnel)', d.speed >= 50, `speed=${d.speed}`);
  t('high-speed swipe triggers chase, run continues', d.state === 'playing');
  t('high-speed push-out + lane revert hold',
    d.lane === 1 && d.px <= d.ox - (2 + d.wid) / 2 * 0.72 + 0.05, JSON.stringify(d));
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

console.log('— Tow truck: side scrape + rear-ender + cleanup —');
{
  const { page, errors, ctx } = await freshPage();
  try {
  await page.evaluate(() => { window.__carway.pickups.nextGap = 1e12; });
  await page.evaluate(() => {
    window.__towScrape = 0; window.__towCrash = 0;
    const s = window.__carway.sound;
    const oS = s.scrape.bind(s), oC = s.crash.bind(s);
    s.scrape = () => { window.__towScrape++; oS(); };
    s.crash = () => { window.__towCrash++; oC(); };
  });
  await startRun(page);
  await clearTraffic(page);
  const pool = await page.evaluate(() => ({ n: __carway.traffic.cars.length,
    tows: __carway.traffic.cars.filter((c) => c.body === 'tow').length }));
  t('traffic pool carries 18 cars incl. 2 tow trucks', pool.n === 18 && pool.tows === 2, JSON.stringify(pool));
  // Side scrape on the tow: chase (not game over), thump once, pushed out.
  const spec = await teleportBody(page, 'tow', 1.35, 0.3);
  t('rigged a truck-class tow truck', spec.kind === 'truck' && spec.len === 6.0 && spec.wid === 2.10,
    JSON.stringify(spec));
  await page.waitForFunction(() => window.__carway.penalty.chase === true, null, { timeout: 45000 });
  const ts = await page.evaluate(() => ({ state: __carway.state, chase: __carway.penalty.chase,
    px: __carway.player.x,
    ox: __carway.traffic.cars.find((c) => c.active).group.position.x,
    scrape: window.__towScrape, crash: window.__towCrash }));
  const towMaxDx = (2 + 2.10) / 2 * 0.72;
  t('tow side scrape starts a chase (not game over)', ts.state === 'playing' && ts.chase === true,
    JSON.stringify(ts));
  t('tow thump fires once, no crash sting', ts.scrape === 1 && ts.crash === 0, JSON.stringify(ts));
  t('no clipping through the tow (pushed to its flank)',
    ts.px < ts.ox && ts.px <= ts.ox - towMaxDx + 0.35, `px=${ts.px} ox=${ts.ox}`);
  // Rear-ender on the tow: game over + crash sting, no new thump.
  await clearTraffic(page);
  await teleportBody(page, 'tow', 0, -2.9);
  await page.waitForFunction(() => window.__carway.state === 'over', null, { timeout: 45000 });
  const tr = await page.evaluate(() => ({ scrape: window.__towScrape, crash: window.__towCrash }));
  t('tow rear-ender plays crash(), not the side thump', tr.crash === 1 && tr.scrape === 1, JSON.stringify(tr));
  // Cleanup: manual update past the limit despawns; reset() clears state.
  const cl = await page.evaluate(() => {
    const g = window.__carway;
    const tow = g.traffic.cars.find((c) => c.body === 'tow');
    tow.active = true; tow.group.visible = true;
    tow.group.position.set(0, 0, 30);
    g.traffic.update(0.016, 20, 0, 0);
    const despawned = tow.active === false && tow.group.visible === false;
    tow.active = true; tow._hitMark = true;
    g.traffic.reset();
    return { despawned, cleared: tow.active === false && tow._hitMark === false };
  });
  t('tow despawns past the limit (no leak)', cl.despawned === true);
  t('traffic reset() clears tow state', cl.cleared === true);
  t('zero page/console errors', errors.length === 0, errors.join(' | ').slice(0, 300));
  } catch (e) { t('scenario finished without timeout/stall', false, String(e).slice(0, 200)); }
  await ctx.close();
}

await browser.close();
console.log(`\n${pass} passed, ${fail} failed.`);
process.exit(fail ? 1 : 0);
