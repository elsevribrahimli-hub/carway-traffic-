// CARWAY TRAFFIC — Headless-browser smoke + gameplay test.
// Run: `node test/browser.test.mjs` (needs the game served at :8080).
// All waits poll GAME state (not wall time), so the test is deterministic
// even under slow software WebGL rendering.
import { chromium } from 'playwright';

const URL = process.env.CARWAY_URL || 'http://127.0.0.1:8080/index.html?nointro=1';
let pass = 0, fail = 0;
const t = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else { fail++; console.log(`  ❌ ${name} ${extra}`); }
};

const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader'] });
const page = await browser.newPage({
  viewport: { width: 390, height: 844 }, // portrait phone
  hasTouch: true, isMobile: true,
  deviceScaleFactor: 2,
});
const errors = [];
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
// Open the nav drawer and wait until its slide transition fully settles
// (sandbox SwiftShader frames can stretch CSS transitions over seconds).
async function openNav(page) {
  await page.tap('#btn-nav');
  await page.waitForFunction(
    () => document.querySelector('#nav-drawer').getBoundingClientRect().left >= -0.5,
    null, { timeout: 15000 });
}

await page.goto(URL, { waitUntil: 'networkidle' });
await page.waitForFunction(() => window.__carway, null, { timeout: 15000 });
await page.waitForTimeout(1500);

const webgl = await page.evaluate(() => {
  const g = window.__carway;
  const gl = g.renderer.getContext();
  const dbg = gl.getExtension('WEBGL_debug_renderer_info');
  return {
    state: g.state,
    version: gl.getParameter(gl.VERSION),
    renderer: dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : 'n/a',
    canvasW: g.renderer.domElement.width, canvasH: g.renderer.domElement.height,
    hasEnv: !!g.scene.environment,
    quality: g.quality, paint: g.save.data.paint,
  };
});
console.log('— Boot —');
console.log('  WebGL:', webgl.version, '|', webgl.renderer, `| canvas ${webgl.canvasW}x${webgl.canvasH}`);
t('game boots to menu state', webgl.state === 'menu');
t('canvas has non-zero size', webgl.canvasW > 0 && webgl.canvasH > 0);
t('procedural environment map built', webgl.hasEnv);
t('fresh boot defaults to Medium quality', webgl.quality === 'medium', webgl.quality);
t('fresh boot defaults to red hero paint', webgl.paint === 'red', webgl.paint);
await page.screenshot({ timeout: 120000, path: 'test/shot-menu.png' });

// ---- Start; wait for real game-time progress (still inside 60m grace zone) ----
await page.tap('#btn-start');
await page.waitForFunction(() => window.__carway.distance > 25, null, { timeout: 90000 });
const s1 = await page.evaluate(() => ({
  state: window.__carway.state, dist: window.__carway.distance,
  score: window.__carway.score, speed: window.__carway.speed,
  fps: document.getElementById('hud-fps').textContent,
  hudDist: document.getElementById('hud-dist').textContent,
}));
console.log('— Gameplay —');
t('start enters playing state', s1.state === 'playing', JSON.stringify(s1));
t('distance increases', s1.dist > 10, `dist=${s1.dist}`);
t('score increases', s1.score > 0, `score=${s1.score}`);
t('HUD shows distance', /[0-9]+ m/.test(s1.hudDist), s1.hudDist);
console.log(`  hud fps label (software render): ${s1.fps}`);

// ---- Lane switching (within grace zone: no traffic, no crash risk) ----
const x0 = await page.evaluate(() => window.__carway.player.x);
await page.keyboard.press('ArrowLeft');
await page.waitForFunction(() => window.__carway.player.laneIndex === 0, null, { timeout: 5000 });
await page.waitForFunction(() => Math.abs(window.__carway.player.x - (-3.2)) < 0.15, null, { timeout: 15000 });
const x1 = await page.evaluate(() => window.__carway.player.x);
t('ArrowLeft moves car to left lane', x1 < x0 - 1, `x ${x0.toFixed(2)} -> ${x1.toFixed(2)}`);
await page.keyboard.press('ArrowRight');
await page.keyboard.press('ArrowRight');
await page.waitForFunction(() => window.__carway.player.laneIndex === 2, null, { timeout: 5000 });
await page.waitForFunction(() => Math.abs(window.__carway.player.x - 3.2) < 0.15, null, { timeout: 15000 });
const x2 = await page.evaluate(() => window.__carway.player.x);
t('ArrowRight x2 moves car to right lane', x2 > x1 + 2, `x -> ${x2.toFixed(2)}`);

// ---- Jump: wait for airborne + rise, then for landing ----
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.player.airborne === true, null, { timeout: 5000 });
await page.waitForFunction(() => window.__carway.player.y > 0.3, null, { timeout: 15000 });
const air = await page.evaluate(() => ({ y: window.__carway.player.y }));
t('jump leaves ground', air.y > 0.3, `y=${air.y.toFixed(2)}`);
await page.waitForFunction(() => window.__carway.player.airborne === false, null, { timeout: 30000 });
const landed = await page.evaluate(() => ({ y: window.__carway.player.y, air: window.__carway.player.airborne }));
t('player lands back', !landed.air && landed.y === 0, JSON.stringify(landed));

// ---- Touch swipe (synthetic TouchEvents: left swipe) ----
await page.evaluate(() => window.__carway.player.laneIndex === 2 || window.__carway.start());
const laneBefore = await page.evaluate(() => window.__carway.player.laneIndex);
await page.evaluate(() => {
  const el = document.getElementById('game-container');
  const mk = (type, x, y) => {
    const touch = new Touch({ identifier: 1, target: el, clientX: x, clientY: y });
    el.dispatchEvent(new TouchEvent(type, { touches: type === 'touchstart' ? [touch] : [], changedTouches: [touch], bubbles: true }));
  };
  mk('touchstart', 300, 400); mk('touchend', 120, 400);
});
await page.waitForFunction((b) => window.__carway.player.laneIndex === b - 1, laneBefore, { timeout: 5000 });
const laneAfter = await page.evaluate(() => window.__carway.player.laneIndex);
t('touch swipe left changes lane', laneAfter === laneBefore - 1, `lane ${laneBefore} -> ${laneAfter}`);

// ---- Traffic: skip grace, wait for real spawns ----
await page.evaluate(() => { window.__carway.traffic.graceLeft = 0; });
await page.waitForFunction(() => window.__carway.traffic.cars.some((c) => c.active), null, { timeout: 60000 });
const traf = await page.evaluate(() => ({
  active: window.__carway.traffic.cars.filter((c) => c.active).length,
  lanes: [...new Set(window.__carway.traffic.cars.filter((c) => c.active).map((c) => c.lane))],
}));
t('traffic cars spawn during play', traf.active > 0, `active=${traf.active} lanes=[${traf.lanes}]`);
await page.waitForTimeout(1500); // let traffic approach for a lively screenshot
await page.screenshot({ timeout: 120000, path: 'test/shot-gameplay.png' });

// ---- Pause / resume ----
await page.tap('#btn-pause');
await page.waitForFunction(() => window.__carway.state === 'paused', null, { timeout: 5000 });
t('pause works', true);
const dPause = await page.evaluate(() => window.__carway.distance);
await page.waitForTimeout(800);
const dPause2 = await page.evaluate(() => window.__carway.distance);
t('distance frozen while paused', dPause === dPause2);
await page.screenshot({ timeout: 120000, path: 'test/shot-pause.png' });
await page.tap('#btn-resume');
await page.waitForFunction(() => window.__carway.state === 'playing', null, { timeout: 5000 });
t('resume works', true);

// ---- Phase 2: settings UI, quality scaling, music, dust ----
console.log('— Phase 2 systems —');
t('quality buttons exist', await page.locator('#btn-quality').count() === 1 && await page.locator('#btn-quality-settings').count() === 1);
t('volume sliders exist', await page.locator('#vol-music').count() === 1 && await page.locator('#vol-sfx').count() === 1);
const qread = async (tier) => page.evaluate((t) => {
  const g = window.__carway; g.setQuality(t);
  return { q: g.quality, pr: g.renderer.getPixelRatio(), shadow: g.sun.castShadow,
    label: document.querySelector('#btn-quality-settings .quality-label').textContent,
    lod: g.traffic.lodFar, budget: g.vapor.budget, scale: g.vapor.countScale, paint: g.player._paintKind };
}, tier);
const ql = await qread('low');
t('low quality applies (ratio 1, shadows off, budgets cut)',
  ql.q === 'low' && ql.pr === 1 && ql.shadow === false && ql.label === 'LOW' &&
  ql.lod === 40 && ql.budget === 20 && ql.scale === 0.5 && ql.paint === 'standard', JSON.stringify(ql));
const qm = await qread('medium');
t('medium quality applies (ratio 1.5, shadows on, mid budgets)',
  qm.q === 'medium' && qm.pr === 1.5 && qm.shadow === true && qm.label === 'MEDIUM' &&
  qm.lod === 55 && qm.budget === 40 && qm.scale === 1 && qm.paint === 'standard', JSON.stringify(qm));
const qh = await qread('high');
t('high quality applies (ratio 2, clearcoat, full budgets)',
  qh.q === 'high' && qh.pr === 2 && qh.shadow === true && qh.label === 'HIGH' &&
  qh.lod === 70 && qh.budget === 64 && qh.scale === 1.25 && qh.paint === 'physical', JSON.stringify(qh));
const qbad = await page.evaluate(() => { window.__carway.setQuality('ultra'); return window.__carway.quality; });
t('invalid quality rejected', qbad === 'high', qbad);
// The pause-screen quality button cycles High -> Low -> Medium -> High.
await page.tap('#btn-pause');
await page.waitForFunction(() => window.__carway.state === 'paused', null, { timeout: 5000 });
await page.locator('#btn-quality').click();
const qcyc = await page.evaluate(() => window.__carway.quality);
t('quality button cycles tiers (high -> low)', qcyc === 'low', qcyc);
await page.locator('#btn-quality').click();
const qcyc2 = await page.evaluate(() => window.__carway.quality);
t('quality button cycles tiers (low -> medium)', qcyc2 === 'medium', qcyc2);
await page.tap('#btn-resume');
await page.waitForFunction(() => window.__carway.state === 'playing', null, { timeout: 5000 });
await page.evaluate(() => window.__carway.setQuality('high'));
const audio = await page.evaluate(() => {
  const s = window.__carway.sound;
  s.setMusicVolume(0.5); s.setSfxVolume(0.8);
  return {
    ctx: !!s.ctx, musicBus: !!s.musicBus, sfxBus: !!s.sfxBus,
    musicTimer: !!s.musicTimer, roadLoop: !!s.roadSrc,
    mv: s.musicVol, sv: s.sfxVol,
  };
});
t('audio engine running (music + road ambience)', audio.ctx && audio.musicBus && audio.sfxBus && audio.musicTimer && audio.roadLoop, JSON.stringify(audio));
t('volume setters persist', audio.mv === 0.5 && audio.sv === 0.8);
const dust = await page.evaluate(() => {
  const g = window.__carway;
  g.setQuality('high');
  g.spawnDust(0, 0, 5);
  return g.dust.filter((p) => p.life > 0).length;
});
t('landing dust spawns', dust >= 5, `active=${dust}`);

// ---- Phase 3: coins, boost, garage, missions ----
console.log('— Phase 3 systems —');
await page.waitForFunction(() => window.__carway.coins.items.some((c) => c.active), null, { timeout: 60000 });
t('coins spawn during play', true);
const coinsBefore = await page.evaluate(() => window.__carway.runCoins);
await page.evaluate(() => {
  const g = window.__carway;
  const c = g.coins.items.find((i) => !i.active) || g.coins.items[0];
  c.active = true; c.root.visible = true;
  c.root.position.set(g.player.x, 0, 0);
  c.spinner.position.y = 0.9;
});
await page.waitForFunction((b) => window.__carway.runCoins > b, coinsBefore, { timeout: 10000 });
const collected = await page.evaluate(() => window.__carway.runCoins);
// HUD repaints on the next rendered frame — poll for it (slow runners lag one frame).
await page.waitForFunction((n) => document.querySelector('#hud-coins').textContent === String(n), collected, { timeout: 15000 });
const hudCoins = await page.locator('#hud-coins').textContent();
t('touching a coin collects it + HUD updates', hudCoins === String(collected) && collected > coinsBefore, `hud=${hudCoins}`);
// Boost
t('nitro button visible while playing', await page.locator('#btn-nitro').isVisible());
const spd0 = await page.evaluate(() => window.__carway.speed);
await page.evaluate(() => window.__carway.activateBoost());
await page.waitForFunction(() => window.__carway.boost.active === true, null, { timeout: 5000 });
// Poll GAME state (meter drains per game-frame), immune to wall-time stalls
// such as the auto-quality shader recompile hitch on slow renderers.
await page.waitForFunction(() => window.__carway.boost.meter < 100, null, { timeout: 30000 });
const bst = await page.evaluate(() => ({
  speed: window.__carway.speed, meter: window.__carway.boost.meter,
  flames: window.__carway.player.boostFlames.filter((f) => f.visible).length,
  css: document.getElementById('game-container').classList.contains('boosting'),
}));
t('boost multiplies speed ~1.6x', bst.speed / spd0 > 1.5 && bst.speed / spd0 < 1.7, `x${(bst.speed / spd0).toFixed(2)}`);
t('boost drains meter + flames + screen glow', bst.meter < 100 && bst.flames === 2 && bst.css, JSON.stringify(bst));
await page.screenshot({ timeout: 120000, path: 'test/shot-boost.png' });
await page.evaluate(() => { window.__carway.boost.meter = 1; });
await page.waitForFunction(() => window.__carway.boost.active === false, null, { timeout: 15000 });
t('boost ends + flames hide', await page.evaluate(() => !window.__carway.player.boostFlames.some((f) => f.visible)));
const mis = await page.evaluate(() => {
  const g = window.__carway;
  const before = g.save.data.coins;
  const done = g.save.checkMissions({ overtakes: 30, distance: 0 });
  return { done: done.map((m) => m.id), reward: g.save.data.coins - before };
});
t('mission completes + pays reward', mis.done.includes('over30') && mis.reward === 40, JSON.stringify(mis));
// Garage: pause -> menu -> garage
await page.tap('#btn-pause');
await page.waitForFunction(() => window.__carway.state === 'paused', null, { timeout: 5000 });
await page.tap('#btn-menu2');
await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
t('pause screen returns to main menu', await page.locator('#start-screen').isVisible());
await page.evaluate(() => { const g = window.__carway; g.save.data.coins = 500; g.save._persist(); g.refreshMenuUI(); });
await openNav(page);
await page.tap('#btn-garage');
await page.waitForFunction(() => window.__carway.state === 'garage', null, { timeout: 5000 });
t('garage opens with 3D preview', await page.locator('#garage-screen').isVisible());
t('6 paint options rendered', await page.locator('#paint-list .paint-row').count() === 6);
await page.screenshot({ timeout: 120000, path: 'test/shot-garage.png' });
const buy = async (name) => page.locator('.paint-row', { hasText: name }).locator('button').click();
await buy('Electric Blue');
let gs = await page.evaluate(() => ({ coins: window.__carway.save.data.coins, paint: window.__carway.save.data.paint }));
t('buy blue deducts 400 + selects', gs.coins === 100 && gs.paint === 'blue', JSON.stringify(gs));
await buy('Pearl White');
gs = await page.evaluate(() => ({ coins: window.__carway.save.data.coins, paint: window.__carway.save.data.paint, hex: window.__carway.player.paintMats[0].color.getHex() }));
t('exact-change white purchase applies paint live', gs.coins === 0 && gs.paint === 'white' && gs.hex === 0xf2f4f6, JSON.stringify(gs));
await buy('Midnight Black');
gs = await page.evaluate(() => ({ coins: window.__carway.save.data.coins, paint: window.__carway.save.data.paint }));
t('poor purchase rejected (no deduction)', gs.coins === 0 && gs.paint === 'white', JSON.stringify(gs));
await page.waitForTimeout(900);
await buy('Racing Red');
gs = await page.evaluate(() => window.__carway.save.data.paint);
t('select owned red works', gs === 'red');
await page.tap('#btn-garage-back');
await page.waitForFunction(() => window.__carway.state === 'menu', null, { timeout: 5000 });
t('garage back returns to menu', true);
await page.reload({ waitUntil: 'networkidle', timeout: 90000 }); // DSF2+High starves reload: allow 90s
await page.waitForFunction(() => window.__carway, null, { timeout: 15000 });
await page.waitForTimeout(1000);
const per = await page.evaluate(() => ({ paint: window.__carway.save.data.paint, coins: window.__carway.save.data.coins, hex: window.__carway.player.paintMats[0].color.getHex() }));
t('paint + balance persist after reload', per.paint === 'red' && per.coins === 0 && per.hex === 0xb81f26, JSON.stringify(per));

// ---- Crash -> game over -> restart ----
await page.evaluate(() => window.__carway.gameOver());
await page.locator('#gameover-screen').waitFor({ state: 'visible', timeout: 90000 });
t('game over overlay appears', true);
await page.screenshot({ timeout: 120000, path: 'test/shot-gameover.png' });
await page.tap('#btn-restart');
await page.waitForFunction(() => window.__carway.state === 'playing' && window.__carway.distance < 40, null, { timeout: 15000 });
t('restart resets run', true);

// ---- Real collision: teleport traffic onto the grounded player ----
const balBefore = await page.evaluate(() => window.__carway.save.data.coins);
await page.evaluate(() => {
  const g = window.__carway;
  g.runCoins = 7; // rig earnings to verify banking + game-over display
  const car = g.traffic.cars.find((c) => c.active) || g.traffic.cars[0];
  car.active = true; car.group.visible = true;
  car.group.position.set(g.player.x, 0, 0); // exactly on player, grounded
});
await page.waitForFunction(() => window.__carway.state === 'over', null, { timeout: 60000 });
t('real collision triggers game over', true);
await page.locator('#gameover-screen').waitFor({ state: 'visible', timeout: 90000 });
t('game over shows coins earned', await page.locator('#over-coins').textContent() === '+7');
const balAfter = await page.evaluate(() => window.__carway.save.data.coins);
t('run coins banked to balance', balAfter === balBefore + 7, `${balBefore} -> ${balAfter}`);

// ---- Real jump-over: airborne player overlapping traffic survives ----
await page.tap('#btn-restart');
await page.waitForFunction(() => window.__carway.state === 'playing', null, { timeout: 15000 });
await page.evaluate(() => {
  const g = window.__carway;
  g.player.y = 1.8; g.player.vy = 0; g.player.airborne = true; // high in the air
  const car = g.traffic.cars[0];
  car.active = true; car.group.visible = true;
  car.group.position.set(g.player.x, 0, 0);
});
await page.waitForTimeout(1200);
t('jumping over traffic avoids crash', await page.evaluate(() => window.__carway.state) === 'playing');

// ---- Jump-clear + vapor (timed clears, nitro+jump, failed jumps) ----
console.log('— Jump clear + vapor —');
const freshRun = async () => {
  await page.evaluate(() => window.__carway.start());
  await page.waitForFunction(() => window.__carway.state === 'playing' && window.__carway.distance > 5, null, { timeout: 60000 });
};
const rigSedan = async (z, rel) => {
  await page.evaluate(([zz, rr]) => {
    const g = window.__carway;
    const c = g.traffic.cars[0]; // sedan
    c.active = true; c.group.visible = true; c.counted = false; c.jumpedOver = false;
    c.speed = g.speed - rr; // exact relative approach speed
    c.lane = 1; c.group.position.set(0, 0, zz);
  }, [z, rel]);
};

// Pin High quality for the VFX assertions (disables mid-suite auto-drop).
await page.evaluate(() => { window.__carway.setQuality('high'); window.__carway.autoQTried = true; });

// 1) Timed jump clears a sedan front-to-back at normal speed (no stuck, no crash)
await freshRun();
await rigSedan(-20, 11);
await page.waitForFunction(() => {
  const z = window.__carway.traffic.cars[0].group.position.z;
  return z <= -5.8 && z >= -7.0;
}, null, { timeout: 90000 });
await page.keyboard.press('ArrowUp');
try {
  await page.waitForFunction(() => {
    const g = window.__carway;
    return Math.abs(g.traffic.cars[0].group.position.z) < 2.5 && g.player.y > 1.8;
  }, null, { timeout: 20000 });
  await page.screenshot({ timeout: 120000, path: 'test/shot-jumpclear.png' });
} catch (e) { /* mid-air pose is best-effort; assertions below are the gate */ }
await page.waitForFunction(() => window.__carway.traffic.cars[0].group.position.z > 7, null, { timeout: 60000 });
t('timed jump clears sedan with no crash', await page.evaluate(() => window.__carway.state) === 'playing');
t('clean clear awards aerial bonus', await page.evaluate(() => window.__carway.aerials) >= 1);
await page.waitForFunction(() => !window.__carway.player.airborne, null, { timeout: 30000 });
const land = await page.evaluate(() => ({ y: window.__carway.player.y, state: window.__carway.state }));
t('lands cleanly, never stuck on traffic', land.y === 0 && land.state === 'playing', JSON.stringify(land));

// 2) Lane change still works while airborne
await page.evaluate(() => { window.__carway.jumpMeter = 100; window.__carway.jumpDelay = 0; }); // full-bar gate: top up
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.player.airborne === true, null, { timeout: 10000 });
await page.keyboard.press('ArrowLeft');
await page.waitForFunction(() => window.__carway.player.laneIndex === 0, null, { timeout: 5000 });
t('lane change works mid-air', await page.evaluate(() => window.__carway.player.airborne) === true);
await page.keyboard.press('ArrowRight'); // back to center for the next rig
await page.waitForFunction(() => !window.__carway.player.airborne, null, { timeout: 30000 });

// 3) Jump vapor burst fires on takeoff, then fades (transient, not permanent)
await page.evaluate(() => { window.__carway.jumpMeter = 100; window.__carway.jumpDelay = 0; }); // full-bar gate: top up
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.vapor.activeCount() > 0, null, { timeout: 10000 });
t('jump takeoff emits vapor burst', true);
// Underbody vapor sustains past the launch surge (vy < 2 = burst long dead,
// airborne = emitAir still feeding).
await page.waitForFunction(() => {
  const g = window.__carway;
  return g.player.airborne && g.player.vy < 2 && g.vapor.activeCount() >= 2;
}, null, { timeout: 15000 });
t('airborne underbody vapor sustains mid-air', true);
await page.waitForFunction(() => !window.__carway.player.airborne, null, { timeout: 30000 });
await page.waitForFunction(() => window.__carway.vapor.activeCount() === 0, null, { timeout: 30000 });
t('jump vapor fades away fully', true);

// 3b) Traffic variety + LOD (direct spawn spam: fast, no wall-time driving)
const variety = await page.evaluate(() => {
  const g = window.__carway;
  const tr = g.traffic;
  tr.reset();
  for (let i = 0; i < 12; i++) tr._spawnRow(0, 20);
  const bodies = tr.spawnedBodies.slice();
  const colors = tr.spawnedColors.slice();
  tr.reset();
  let consec = false;
  for (let i = 1; i < bodies.length; i++) if (bodies[i] === bodies[i - 1]) consec = true;
  return { n: bodies.length, distinct: new Set(bodies).size, consec,
    redSpawn: colors.includes(0xb81f26), pool: tr.cars.length };
});
t('direct spawns vary bodies, never repeat consecutively',
  variety.n >= 10 && variety.distinct >= 4 && !variety.consec, JSON.stringify(variety));
t('spawned traffic never player-red', !variety.redSpawn);
t('traffic pool stays 18 (no growth)', variety.pool === 18);
// LOD flips live with distance (rigged car frozen mid-road, then released).
await page.evaluate(() => {
  const g = window.__carway;
  const c = g.traffic.cars[0];
  c.active = true; c.counted = false; c.speed = g.speed; // frozen relative
  c.group.visible = true; c.group.position.set(0, 0, -120);
});
await page.waitForFunction(() => {
  const c = window.__carway.traffic.cars[0];
  return c.simple.visible && !c.detail.visible;
}, null, { timeout: 10000 });
t('far traffic uses simple LOD live', true);
await page.evaluate(() => { window.__carway.traffic.cars[0].group.position.z = -10; });
await page.waitForFunction(() => {
  const c = window.__carway.traffic.cars[0];
  return c.detail.visible && !c.simple.visible;
}, null, { timeout: 10000 });
t('near traffic uses detail LOD live', true);
await page.evaluate(() => {
  const c = window.__carway.traffic.cars[0];
  c.active = false; c.group.visible = false;
});

// 4) Nitro + jump combined: boost via the touch button, clear while purging
await freshRun();
await page.tap('#btn-nitro');
await page.waitForFunction(() => window.__carway.boost.active === true, null, { timeout: 10000 });
await page.waitForFunction(() => window.__carway.vapor.activeCount() > 2, null, { timeout: 15000 });
t('nitro purge emits sustained vapor', true);
await rigSedan(-20, 14);
await page.waitForFunction(() => {
  const z = window.__carway.traffic.cars[0].group.position.z;
  return z <= -5.8 && z >= -7.0;
}, null, { timeout: 90000 });
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.traffic.cars[0].group.position.z > 7, null, { timeout: 60000 });
const combo = await page.evaluate(() => ({ state: window.__carway.state, aerials: window.__carway.aerials }));
t('nitro+jump clears sedan, no crash', combo.state === 'playing' && combo.aerials >= 1, JSON.stringify(combo));

// 5) Failed jump (too late) still crashes normally -> game over
await freshRun();
await rigSedan(-3, 11); // sedan already inside the window: unjumpable
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.state === 'over', null, { timeout: 60000 });
t('failed jump keeps normal collision -> game over', true);
await page.locator('#gameover-screen').waitFor({ state: 'visible', timeout: 90000 });
t('game-over screen after failed jump', true);
await page.waitForFunction(() => window.__carway.vapor.activeCount() === 0, null, { timeout: 30000 });
t('vapor settles after crash (no stuck particles)', true);

// ---- Roadworks edges, traffic density, jump energy meter ----
console.log('— Roadworks + jump meter —');

// Steering-only survival bot: proves lane changes alone thread the traffic
// (never jumps, never boosts). Dodges the nearest row; optional stopFn ends
// the drive early. Returns the last sampled state.
const steerOnlyDrive = async (targetDist, timeoutMs, stopFn = null) => {
  const t0 = Date.now();
  let last = null;
  while (Date.now() - t0 < timeoutMs) {
    last = await page.evaluate(() => {
      const g = window.__carway;
      if (g.state !== 'playing') return { state: g.state, dist: g.distance };
      const near = g.traffic.cars.filter((c) => c.active && c.group.position.z > -32 && c.group.position.z < 8);
      // Every lane with a car anywhere in the window counts as blocked
      // (no anchor clustering: a staggered second car must never be unseen).
      const blocked = [...new Set(near.map((c) => c.lane))];
      const nearestLane = near.length
        ? near.reduce((a, b) => (a.group.position.z > b.group.position.z ? a : b)).lane : -1;
      return {
        state: 'playing', dist: g.distance, lane: g.player.laneIndex, blocked, nearestLane,
        haz: g.traffic.hazards.some((h) => h.active),
      };
    });
    if (last.state !== 'playing' || last.dist >= targetDist) return last;
    if (stopFn && stopFn(last)) return last;
    if (last.blocked.includes(last.lane)) {
      let free = [0, 1, 2].filter((l) => !last.blocked.includes(l));
      if (!free.length) {
        // All lanes occupied: flee the lane with the nearest car.
        free = [0, 1, 2].filter((l) => l !== last.nearestLane);
      }
      if (free.length) {
        const goal = free.sort((a, b) => Math.abs(a - last.lane) - Math.abs(b - last.lane))[0];
        if (goal !== last.lane) await page.evaluate((d) => window.__carway.steer(d), Math.sign(goal - last.lane));
      }
    }
    await page.waitForTimeout(100);
  }
  return last;
};

// A) 500 m steering-only drive: survival + live spawner fairness stats
// (420 s wall-clock hang-guard: game distance is what matters; software
// WebGL under sandbox load can run game-time far slower than wall-time.
// Medium = the game's default; the drive measures steering fairness,
// which is quality-independent, so don't pay High's 2x pixels for it.)
await page.evaluate(() => window.__carway.setQuality('medium'));
await freshRun();
const driveEnd = await steerOnlyDrive(500, 420000);
t('steering alone survives 500m (jump/nitro not needed)', !!driveEnd && driveEnd.state === 'playing' && driveEnd.dist >= 500,
  JSON.stringify(driveEnd && { dist: Math.round(driveEnd.dist), state: driveEnd.state }));
const drive = await page.evaluate(() => {
  const g = window.__carway;
  return {
    distance: Math.round(g.distance),
    rows: g.traffic.rowsSpawned,
    cars: g.traffic.carsSpawned,
    maxBlocked: g.traffic.maxBlockedInRow,
    minGap: g.traffic.minRowGap,
    history: g.traffic.rowHistory,
    works: g.traffic.worksSpawned,
    bbMap: !!g.road._bbArtMat.map,
    carX: g.traffic.cars.filter((c) => c.active).map((c) => c.group.position.x),
  };
});
let rowsFair = drive.history.length > 3;
let prevFree = [0, 1, 2];
for (const blocked of drive.history) {
  const free = [0, 1, 2].filter((l) => !blocked.includes(l));
  if (blocked.length > 2 || free.length === 0) { rowsFair = false; break; }
  if (!prevFree.some((a) => free.some((b) => Math.abs(a - b) <= 1))) { rowsFair = false; break; }
  prevFree = free;
}
t('spawned rows always leave a connected free lane', rowsFair, `rows=${drive.rows}`);
t('row gaps stay wide for steering', drive.minGap >= 24, `minGap=${drive.minGap === Infinity ? 'n/a' : drive.minGap.toFixed(1)}`);
t('traffic density is low', drive.cars <= (drive.distance / 100) * 4 + 2, `cars=${drive.cars} dist=${drive.distance}`);
t('lane-blocking barriers are gone', await page.evaluate(() => !('barriers' in window.__carway.traffic)));
t('traffic cars sit only in lane centers', drive.carX.length > 0 && drive.carX.every((x) => [-3.2, 0, 3.2].includes(x)), `x=[${drive.carX}]`);
t('roadworks zones spawn during play', drive.works >= 1, `works=${drive.works}`);
t('billboard logo survives 500m of segment recycling', drive.bbMap === true);

// B) Live-spawned roadworks hazards: road edges only, then pose one for evidence
const hazWait = await steerOnlyDrive(100000, 120000, (s) => s.haz === true);
const hazX = await page.evaluate(() => window.__carway.traffic.hazards.filter((h) => h.active).map((h) => h.group.position.x));
t('roadworks hazards stay at the road edges', !!hazWait && hazWait.state === 'playing' && hazX.length > 0 && hazX.every((x) => Math.abs(x) >= 4.5), `x=[${hazX}]`);
await page.evaluate(() => {
  const g = window.__carway;
  const h = g.traffic.hazards.find((hh) => hh.active) || g.traffic.hazards[0];
  h.active = true; h.group.visible = true;
  h.group.position.set(5.0, 0, -18);
});
await page.screenshot({ timeout: 120000, path: 'test/shot-roadworks.png' });

// C) Jump energy meter: drain, gates, recharge, touch button, depleted visuals
await freshRun();
await page.evaluate(() => {
  const g = window.__carway;
  g.traffic.graceLeft = 1e9; // suppress spawns: isolated meter test, no crashes
  for (const c of g.traffic.cars) { c.active = false; c.group.visible = false; }
  for (const h of g.traffic.hazards) { h.active = false; h.group.visible = false; }
});
t('jump meter starts full', await page.evaluate(() => window.__carway.jumpMeter) === 100);
t('jump bar shows charged state', await page.evaluate(() => {
  const f = document.querySelector('#jump-fill');
  return f.style.width === '100%' && f.classList.contains('full') && !f.classList.contains('low');
}));
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.player.airborne === true, null, { timeout: 10000 });
const drained = await page.evaluate(() => window.__carway.jumpMeter);
t('one jump empties the entire bar', drained < 5, `meter=${drained.toFixed(1)}`);
// Wait for gravity to actually tick (wall-clock sleeps hold zero physics
// frames on slow runners, freezing vy at exactly 11.50).
await page.waitForFunction(() => window.__carway.player.vy < 11.49, null, { timeout: 15000 });
const v1 = await page.evaluate(() => window.__carway.player.vy);
await page.keyboard.press('ArrowUp');
const v2 = await page.evaluate(() => window.__carway.player.vy);
const stillAir = await page.evaluate(() => window.__carway.player.airborne);
t('jump cannot repeat while airborne', v2 <= v1 && v2 < 11.5 && stillAir === true, `vy ${v1.toFixed(2)} -> ${v2.toFixed(2)}`);
await page.waitForFunction(() => !window.__carway.player.airborne, null, { timeout: 30000 });
// Lands with the bar still recharging -> grounded press must not jump.
await page.keyboard.press('ArrowUp');
await page.waitForTimeout(300);
const recharging = await page.evaluate(() => ({ air: window.__carway.player.airborne, y: window.__carway.player.y, meter: window.__carway.jumpMeter }));
t('jump blocked while recharging (grounded)', recharging.air === false && recharging.y === 0, JSON.stringify(recharging));
await page.waitForFunction(() => window.__carway.jumpMeter >= 100, null, { timeout: 120000 });
t('jump meter recharges automatically to full', true);
await page.evaluate(() => { window.__carway.jumpMeter = 90; });
await page.keyboard.press('ArrowUp');
await page.waitForTimeout(300);
const denied = await page.evaluate(() => ({ air: window.__carway.player.airborne, y: window.__carway.player.y }));
t('jump blocked with insufficient energy (even 90%)', denied.air === false && denied.y === 0, JSON.stringify(denied));
await page.evaluate(() => { window.__carway.jumpMeter = 100; });
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.player.airborne === true, null, { timeout: 10000 });
t('jump works only at 100% meter', true);
await page.waitForFunction(() => !window.__carway.player.airborne && window.__carway.jumpMeter >= 100, null, { timeout: 150000 });
await page.tap('#btn-jump');
await page.waitForFunction(() => window.__carway.player.airborne === true, null, { timeout: 10000 });
t('touch jump button respects the meter', true);
await page.waitForFunction(() => !window.__carway.player.airborne, null, { timeout: 30000 });
await page.evaluate(() => { window.__carway.jumpMeter = 10; });
await page.waitForFunction(() => document.querySelector('#btn-jump').classList.contains('depleted'), null, { timeout: 5000 });
const lowBar = await page.evaluate(() => document.querySelector('#jump-fill').classList.contains('low'));
t('jump button + bar show unavailable state', lowBar === true);

// D) Jump recharge duration matches nitro (game-time measured, independent)
await freshRun();
await page.evaluate(() => {
  const g = window.__carway;
  g.traffic.graceLeft = 1e9; // suppress spawns: isolated timing test
  for (const c of g.traffic.cars) { c.active = false; c.group.visible = false; }
  for (const h of g.traffic.hazards) { h.active = false; h.group.visible = false; }
  g.jumpMeter = 0; g.jumpDelay = 1.0; // post-jump state
});
const jt0 = await page.evaluate(() => window.__carway.runTime);
await page.waitForFunction(() => window.__carway.jumpMeter >= 100, null, { timeout: 150000 });
const jt1 = await page.evaluate(() => window.__carway.runTime);
await page.evaluate(() => {
  const g = window.__carway;
  g.boost.meter = 0; g.boost.regenDelay = 1.0; g.boost.active = false; // post-nitro state
});
const nt0 = await page.evaluate(() => window.__carway.runTime);
await page.waitForFunction(() => window.__carway.boost.meter >= 100, null, { timeout: 150000 });
const nt1 = await page.evaluate(() => window.__carway.runTime);
const jumpFull = jt1 - jt0, nitroFull = nt1 - nt0;
t('jump recharge takes as long as nitro recharge', Math.abs(jumpFull - nitroFull) < 0.6 && jumpFull > 7 && jumpFull < 9.5,
  `jump=${jumpFull.toFixed(2)}s nitro=${nitroFull.toFixed(2)}s`);
const indep = await page.evaluate(() => {
  const g = window.__carway;
  g.jumpMeter = 100; g.jumpDelay = 0; g.boost.meter = 100; g.boost.regenDelay = 0;
  g.jump();
  return { jump: g.jumpMeter, nitro: g.boost.meter };
});
t('jump and nitro meters stay independent', indep.jump === 0 && indep.nitro === 100, JSON.stringify(indep));

// E) Jump upgrades: upgrades screen shop, coins, persistence, longer airtime
await page.evaluate(() => {
  const g = window.__carway;
  g.toMenu();
  g.save.data.coins = 1000; g.save._persist();
});
await openNav(page);
await page.tap('#btn-upgrades');
await page.waitForFunction(() => window.__carway.state === 'upgrades', null, { timeout: 5000 });
const shop0 = await page.evaluate(() => {
  const card = document.querySelector('[data-upgrade="jump"]');
  return {
    level: card.querySelector('.up-level').textContent,
    dur: card.querySelector('.up-dur').textContent,
    price: card.querySelector('.up-price').textContent,
    btn: card.querySelector('.up-btn').textContent,
    disabled: card.querySelector('.up-btn').disabled,
  };
});
t('upgrades screen shows jump card + price', shop0.level === 'LV 1/5' && shop0.dur.includes('1.15') &&
  shop0.dur.includes('1.25') && shop0.price.includes('150') && shop0.btn === 'UPGRADE' && shop0.disabled === false,
  JSON.stringify(shop0));
await page.tap('[data-upgrade="jump"] .up-btn');
const shop1 = await page.evaluate(() => {
  const card = document.querySelector('[data-upgrade="jump"]');
  return {
    coins: window.__carway.save.data.coins,
    level: card.querySelector('.up-level').textContent,
    dur: card.querySelector('.up-dur').textContent,
  };
});
t('upgrade purchase deducts coins + levels up', shop1.coins === 850 && shop1.level === 'LV 2/5' &&
  shop1.dur.includes('1.25'), JSON.stringify(shop1));
await page.evaluate(() => {
  const g = window.__carway;
  g.save.data.coins = 10; g.ui.refreshUpgrades(g.save.data);
});
t('upgrade disabled with insufficient coins', await page.evaluate(() =>
  document.querySelector('[data-upgrade="jump"] .up-btn').disabled) === true);
await page.evaluate(() => {
  const g = window.__carway;
  g.save.data.coins = 50000; g.ui.refreshUpgrades(g.save.data);
});
await page.tap('[data-upgrade="jump"] .up-btn'); // LV3 (300)
await page.tap('[data-upgrade="jump"] .up-btn'); // LV4 (450)
await page.tap('[data-upgrade="jump"] .up-btn'); // LV5 (600)
const shopMax = await page.evaluate(() => {
  const card = document.querySelector('[data-upgrade="jump"]');
  return {
    coins: window.__carway.save.data.coins,
    level: card.querySelector('.up-level').textContent,
    btn: card.querySelector('.up-btn').textContent,
    disabled: card.querySelector('.up-btn').disabled,
  };
});
t('max level reached, progressive prices paid', shopMax.coins === 50000 - 300 - 450 - 600 && shopMax.level === 'LV 5/5' &&
  shopMax.btn === 'MAXED' && shopMax.disabled === true, JSON.stringify(shopMax));
await page.reload({ waitUntil: 'networkidle', timeout: 90000 }); // DSF2+High starves reload: allow 90s
await page.waitForFunction(() => window.__carway, null, { timeout: 15000 });
await page.waitForTimeout(1000);
const persisted = await page.evaluate(() => {
  const g = window.__carway;
  return { level: g.save.data.upgrades.jump, air: (2 * 11.5) / Math.abs(g.player.gravity) };
});
t('jump level + longer airtime persist after reload', persisted.level === 5 && Math.abs(persisted.air - 1.60) < 0.02, JSON.stringify(persisted));
// Live jump at LV5 stays airborne longer than the 1.15s base.
await page.evaluate(() => {
  const g = window.__carway;
  g.start();
  g.traffic.graceLeft = 1e9;
  for (const c of g.traffic.cars) { c.active = false; c.group.visible = false; }
});
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.player.airborne === true, null, { timeout: 30000 });
const air0 = await page.evaluate(() => window.__carway.runTime);
await page.waitForFunction(() => !window.__carway.player.airborne, null, { timeout: 90000 }); // LV5 air needs wall margin
const air1 = await page.evaluate(() => window.__carway.runTime);
const landedUp = await page.evaluate(() => ({ y: window.__carway.player.y, state: window.__carway.state }));
t('upgraded jump floats longer + lands cleanly', air1 - air0 > 1.4 && air1 - air0 < 1.8 && landedUp.y === 0 && landedUp.state === 'playing',
  `air=${(air1 - air0).toFixed(2)}s`);
// Base level still jumps the classic 1.15s (start() applies saved level).
await page.evaluate(() => {
  const g = window.__carway;
  g.save.data.upgrades.jump = 1; g.save._persist();
  g.start();
  g.traffic.graceLeft = 1e9;
});
await page.keyboard.press('ArrowUp');
await page.waitForFunction(() => window.__carway.player.airborne === true, null, { timeout: 30000 });
const b0 = await page.evaluate(() => window.__carway.runTime);
await page.waitForFunction(() => !window.__carway.player.airborne, null, { timeout: 90000 });
const b1 = await page.evaluate(() => window.__carway.runTime);
t('base jump keeps classic airtime', b1 - b0 > 1.0 && b1 - b0 < 1.3, `air=${(b1 - b0).toFixed(2)}s`);
// Not-ready message.
await page.evaluate(() => { window.__carway.jumpMeter = 50; });
await page.keyboard.press('ArrowUp');
const toast = await page.locator('#hud-toast').textContent();
t('not-ready jump shows a clear message', toast === 'JUMP CHARGING…', toast);

console.log('— Perf + stability (budgets, auto-Q, context, orientation) —');
// GPU resource budgets while playing (shared road geometry keeps this low).
const budgets = await page.evaluate(() => ({ geos: __carway.renderer.info.memory.geometries,
  texs: __carway.renderer.info.memory.textures, calls: __carway.renderer.info.render.calls }));
t('shared geometry keeps GPU buffers low', budgets.geos < 200, JSON.stringify(budgets));
t('texture count stays tiny (all procedural)', budgets.texs <= 14, JSON.stringify(budgets));
t('draw calls stay within the mobile budget', budgets.calls < 600, JSON.stringify(budgets));
// Auto-Q wiring: faked poor counters step high -> medium with a toast.
await page.evaluate(() => {
  const g = window.__carway;
  g.setQuality('high'); g.autoQTried = false;
  g.qtAcc = 3; g.qtN = 30; g.qtTime = 1.99; g._aqGood = 0;
});
await page.waitForFunction(() => window.__carway.quality === 'medium', null, { timeout: 8000 });
const aqToast = await page.locator('#hud-toast').textContent();
t('sustained poor frames step quality down (auto)', aqToast.includes('(auto)'), aqToast);
await page.evaluate(() => { window.__carway.autoQTried = true; window.__carway.setQuality('high'); });
// Visibility auto-pause pins the existing backgrounding behavior.
await page.evaluate(() => {
  Object.defineProperty(document, 'hidden', { value: true, configurable: true });
  document.dispatchEvent(new Event('visibilitychange'));
});
await page.waitForFunction(() => window.__carway.state === 'paused', null, { timeout: 5000 });
t('hidden tab auto-pauses the run', true);
await page.evaluate(() => {
  Object.defineProperty(document, 'hidden', { value: false, configurable: true });
  document.dispatchEvent(new Event('visibilitychange'));
});
await page.waitForTimeout(400);
const stillPaused = await page.evaluate(() => window.__carway.state);
t('returning does not auto-resume (user resumes)', stillPaused === 'paused', stillPaused);
await page.tap('#btn-resume');
await page.waitForFunction(() => window.__carway.state === 'playing', null, { timeout: 5000 });
// WebGL context loss parks gameplay; restore continues rendering.
const ctxLost = await page.evaluate(() => {
  const r = window.__carway.renderer;
  if (typeof r.forceContextLoss !== 'function') return 'no-api';
  r.forceContextLoss();
  return 'lost';
});
t('context-loss API available', ctxLost === 'lost', ctxLost);
await page.waitForFunction(() => window.__carway.state === 'paused', null, { timeout: 5000 });
const lostToast = await page.locator('#hud-toast').textContent();
t('context loss pauses + warns', lostToast.includes('GRAPHICS RESET'), lostToast);
await page.evaluate(() => {
  window.__carway.renderer.forceContextRestore();
});
await page.waitForFunction(() => document.getElementById('hud-toast').textContent.includes('GRAPHICS RESTORED'),
  null, { timeout: 15000 });
await page.waitForTimeout(800);
const postCalls = await page.evaluate(() => window.__carway.renderer.info.render.calls);
t('rendering continues after restore', postCalls > 0, `calls=${postCalls}`);
await page.tap('#btn-resume');
await page.waitForFunction(() => window.__carway.state === 'playing', null, { timeout: 5000 });
// Landscape: the 9:16 shell letterboxes (portrait game by design), rendering
// continues. At 844x390 the shell is 219x366 -> aspect ~0.599.
await page.setViewportSize({ width: 844, height: 390 });
await page.waitForTimeout(800);
const lscape = await page.evaluate(() => ({ aspect: +window.__carway.camera.aspect.toFixed(3),
  calls: window.__carway.renderer.info.render.calls, state: window.__carway.state }));
t('landscape letterboxes to the portrait shell, rendering holds',
  Math.abs(lscape.aspect - 0.599) < 0.02 && lscape.calls > 0 && lscape.state === 'playing',
  JSON.stringify(lscape));
await page.setViewportSize({ width: 390, height: 844 });
await page.waitForTimeout(500);
// Fresh boot into saved Low disables MSAA (boot-time decision).
// (The main page is done — only the in-memory errors array is still needed
// below — so close it first: two live WebGL pages starve software GL.)
await page.close();
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('carway_quality', 'low'); } catch (e) {} });
  const lp = await ctx.newPage();
  await lp.goto(URL, { waitUntil: 'domcontentloaded' });
  await lp.waitForFunction(() => window.__carway, null, { timeout: 30000 });
  const aa = await lp.evaluate(() => ({
    q: __carway.quality,
    msaa: __carway.renderer.domElement.getContext('webgl2').getContextAttributes().antialias }));
  t('saved-Low boot disables MSAA', aa.q === 'low' && aa.msaa === false, JSON.stringify(aa));
  await ctx.close();
}
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const hp = await ctx.newPage();
  await hp.goto(URL, { waitUntil: 'domcontentloaded' });
  await hp.waitForFunction(() => window.__carway, null, { timeout: 30000 });
  const aa = await hp.evaluate(() => ({
    msaa: __carway.renderer.domElement.getContext('webgl2').getContextAttributes().antialias }));
  t('default boot keeps MSAA', aa.msaa === true, JSON.stringify(aa));
  await ctx.close();
}

console.log('— Errors —');
t('zero page/console errors', errors.length === 0, errors.slice(0, 5).join(' | '));

await browser.close();
console.log(`\n${pass} passed, ${fail} failed.`);
process.exit(fail ? 1 : 0);
