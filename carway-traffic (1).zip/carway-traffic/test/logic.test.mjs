// CARWAY TRAFFIC — Phase 1 logic tests (run with `node test/logic.test.mjs`).
// Covers: lane switching, jumping, collisions, fair-gap spawning, difficulty,
// scoring inputs and swipe decisions. No WebGL needed.
import {
  CONF, LANES_X, moveLane, laneX, playerSpeedFor, spawnGapFor,
  rowHasFreeLane, rowsConnect, freeLanes, checkCollision, classifyCollision, BILLBOARDS,
  stepJump, jumpApex, difficulty01, doubleRowChanceFor,
  PAINTS, paintById, CARS, carById, TRAFFIC_COLORS, QUALITY_LEVELS, QUALITY_ORDER, autoQualityStep,
  DEFAULT_QUALITY, coinHit, coinAward, boostCanStart, jumpCanStart, overlapXZ,
  timeAboveClearance, zWindowLength, canClearJump, pickBlockedLanes,
  jumpAirtimeFor, jumpGravityFor, fullRechargeTime,
  UPGRADES, UPGRADE_IDS, upgradeDef, upgradeDuration, upgradePrice,
  upgradeLevelMax, clampUpgradeLevel, magnetRadiusFor,
  fairWindow, clusterObstacles, minLaneChanges, fairTimeGap, fieldViolations,
  sidePushOut,
} from '../js/config.js';
import * as THREE from '../libs/three.module.js';
import { swipeAction } from '../js/systems/input.js';
import { SaveData } from '../js/systems/save.js';
import { SoundSystem } from '../js/systems/sound.js';
import { MISSIONS, missionById, missionProgress, featuredMission } from '../js/systems/missions.js';
import { buildPlayerCar } from '../js/systems/player.js';
import { buildTrafficCar, BODY_ORDER, BODY_SPECS, TrafficSystem } from '../js/systems/traffic.js';
import { PickupsSystem } from '../js/systems/pickups.js';
import { PoliceSystem } from '../js/systems/police.js';

let pass = 0, fail = 0;
function t(name, cond) {
  if (cond) { pass++; console.log(`  ✅ ${name}`); }
  else { fail++; console.log(`  ❌ ${name}`); }
}

console.log('— Lanes —');
t('3 lanes defined', LANES_X.length === 3);
t('moveLane clamps left edge', moveLane(0, -1) === 0);
t('moveLane clamps right edge', moveLane(2, 1) === 2);
t('moveLane center->left', moveLane(1, -1) === 0);
t('moveLane center->right', moveLane(1, 1) === 2);
t('laneX(0) < laneX(1) < laneX(2)', laneX(0) < laneX(1) && laneX(1) < laneX(2));

console.log('— Jump physics —');
t('jump apex ~3.3m', jumpApex() > 3.1 && jumpApex() < 3.5);
t('apex clears sedans + SUVs with margin', jumpApex() > CONF.clearHeightSuv + 1.0);
t('jump apex clears roadworks', jumpApex() > CONF.clearHeightWorks);
{
  let y = 0, vy = CONF.jumpVelocity, air = 0;
  for (let i = 0; i < 600; i++) { const s = stepJump(y, vy, 1 / 60); y = s.y; vy = s.vy; air += 1 / 60; if (s.landed) break; }
  t('jump lands back on ground', y === 0);
  t('air time sane (0.5s..1.4s)', air > 0.5 && air < 1.4);
}

console.log('— Collisions —');
t('head-on overlap = hit', checkCollision(0, 0, 0, 0, 0, 4.2, 2.0, CONF.clearHeightSedan) === true);
t('adjacent lane = no hit', checkCollision(-3.2, 0, 0, 0, 0, 4.2, 2.0, CONF.clearHeightSedan) === false);
t('far ahead = no hit', checkCollision(0, 0, 0, 0, -10, 4.2, 2.0, CONF.clearHeightSedan) === false);
t('high jump clears sedan', checkCollision(0, 0, 2.2, 0, 0, 4.2, 2.0, CONF.clearHeightSedan) === false);
t('low jump still hits sedan', checkCollision(0, 0, 0.5, 0, 0, 4.2, 2.0, CONF.clearHeightSedan) === true);
t('mid jump hits tall SUV but clears sedan', checkCollision(0, 0, 1.7, 0, 0, 4.5, 2.0, CONF.clearHeightSuv) === true &&
  checkCollision(0, 0, 1.7, 0, 0, 4.3, 1.95, CONF.clearHeightSedan) === false);
t('overlapXZ ignores height', overlapXZ(0, 0, 0, 0, 4.2, 2.0) === true && overlapXZ(-3.2, 0, 0, 0, 4.2, 2.0) === false);
t('jump clears roadworks', checkCollision(0, 0, 1.4, 0, 0, CONF.worksLen, CONF.worksWid, CONF.clearHeightWorks) === false);
t('grounded hits roadworks', checkCollision(0, 0, 0, 0, 0, CONF.worksLen, CONF.worksWid, CONF.clearHeightWorks) === true);
// Edge works zones sit fully outside every lane's driving corridor.
t('works zone never overlaps outer lane', overlapXZ(3.2, 0, CONF.worksEdgeX, 0, CONF.worksLen, CONF.worksWid) === false);
t('works zone never overlaps center lane', overlapXZ(0, 0, -CONF.worksEdgeX, 0, CONF.worksLen, CONF.worksWid) === false);
t('works zone hugs the road edge', CONF.worksEdgeX + CONF.worksWid / 2 <= CONF.roadWidth / 2 + 0.5 &&
  CONF.worksEdgeX - CONF.worksWid / 2 > 3.2);

console.log('— Fair-gap spawning —');
t('row never blocks all 3 lanes', rowHasFreeLane([0, 1]) && !rowHasFreeLane([0, 1, 2]));
t('freeLanes correct', JSON.stringify(freeLanes([0, 2])) === JSON.stringify([1]));
t('same free lane connects', rowsConnect([1], [1]) === true);
t('adjacent free lanes connect', rowsConnect([0], [1]) === true);
t('opposite lanes do NOT connect directly', rowsConnect([0], [2]) === false);
// Fuzz the PRODUCTION row picker: 2000 rows at every difficulty level must
// each leave a free lane, never block 3, and connect to the previous row.
{
  let fair = true, maxBlocked = 0;
  for (const dist of [0, 800, 1600, 2500, 5000]) {
    let prevFree = [0, 1, 2];
    for (let i = 0; i < 2000; i++) {
      const blocked = pickBlockedLanes(prevFree, doubleRowChanceFor(dist));
      if (blocked.length > maxBlocked) maxBlocked = blocked.length;
      if (!rowHasFreeLane(blocked)) { fair = false; break; }
      const free = freeLanes(blocked);
      if (!rowsConnect(prevFree, free)) { fair = false; break; }
      prevFree = free;
    }
    if (!fair) break;
  }
  t('10000 production rows all fair + connected', fair);
  t('production rows never block 3 lanes', maxBlocked <= 2);
}

console.log('— Difficulty —');
t('speed starts at startSpeed', playerSpeedFor(0) === CONF.startSpeed);
t('speed increases with distance', playerSpeedFor(1000) > playerSpeedFor(0));
t('speed capped at maxSpeed', playerSpeedFor(999999) === CONF.maxSpeed);
t('gap shrinks with distance', spawnGapFor(3000) < spawnGapFor(0));
t('difficulty saturates at 1', difficulty01(999999) === 1);
// Reduced density: wide row gaps + rare double rows => lane steering suffices.
t('row gaps are wide (48m -> 26m)', spawnGapFor(0) >= 45 && spawnGapFor(999999) >= 24);
t('double rows are rare (10% -> 35%)',
  doubleRowChanceFor(0) <= 0.15 && doubleRowChanceFor(999999) <= 0.4);
t('traffic is slower than player, same direction',
  CONF.trafficSpeedMin >= 0.4 && CONF.trafficSpeedMax <= 0.6 && CONF.trafficSpeedMin < CONF.trafficSpeedMax);
t('works zones spawn sparsely at edges only',
  CONF.worksGapMin >= 60 && CONF.worksGapMax > CONF.worksGapMin);

console.log('— Swipe input —');
t('swipe left', swipeAction(-80, 5) === 'left');
t('swipe right', swipeAction(80, -3) === 'right');
t('swipe up', swipeAction(4, -90) === 'up');
t('small drift = tap (ignored)', swipeAction(5, 5) === 'tap');
t('diagonal picks dominant axis', swipeAction(-30, -90) === 'up');

console.log('— Paints / shop —');
t('6 paints incl. silver/black/white/red/blue/yellow',
  PAINTS.length === 6 && ['silver', 'black', 'white', 'red', 'blue', 'yellow'].every((id) => PAINTS.some((p) => p.id === id)));
t('red is first + free, blue costs 400, yellow costs 250',
  PAINTS[0].id === 'red' && paintById('red').price === 0 && paintById('blue').price === 400 && paintById('yellow').price === 250);
t('yellow paint def is a valid gold color', paintById('yellow').color === 0xf7c500 && paintById('yellow').dark === 0x8a6d00);
t('paintById falls back to red', paintById('nope').id === 'red');
{
  const s = new SaveData(null); // in-memory (no localStorage in node)
  t('fresh save: 0 coins, red owned+selected',
    s.data.coins === 0 && s.ownsPaint('red') && s.data.paint === 'red');
  const poor = s.buyPaint(paintById('blue'));
  t('cannot buy without coins (no deduction)',
    poor.ok === false && poor.reason === 'coins' && s.data.coins === 0 && !s.ownsPaint('blue'));
  s.bankRun(500, { overtakes: 0, distance: 0 });
  t('bankRun adds balance + lifetime', s.data.coins >= 500 && s.data.totalBanked === 500);
  const bought = s.buyPaint(paintById('blue'));
  // 500 banked + 50 bank100-mission reward - 400 blue paint = 150
  t('valid purchase deducts + unlocks + selects',
    bought.ok && s.data.coins === 150 && s.ownsPaint('blue') && s.data.paint === 'blue');
  t('re-buy owned paint is free', s.buyPaint(paintById('blue')).ok && s.data.coins === 150);
  t('cannot select unowned paint', s.selectPaint('black') === false && s.data.paint === 'blue');
  t('select owned paint works', s.selectPaint('red') === true && s.data.paint === 'red');
}
{
  // Legacy saves (pre-red-default) migrate: red is granted, valid
  // selections survive, invalid selections fall back to red.
  const store = {};
  const mem = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
  mem.setItem('carway_paints', JSON.stringify(['silver', 'blue']));
  mem.setItem('carway_paint', JSON.stringify('blue'));
  const s = new SaveData(mem);
  t('legacy save gains red, keeps valid selection',
    s.ownsPaint('red') && s.ownsPaint('silver') && s.data.paint === 'blue');
  mem.setItem('carway_paint', JSON.stringify('gold'));
  const s2 = new SaveData(mem);
  t('invalid legacy selection falls back to red', s2.data.paint === 'red');
}

console.log('— Missions —');
t('3 missions defined', MISSIONS.length === 3);
t('missionById works', missionById('over30').target === 30);
{
  const s = new SaveData(null);
  t('featured mission is bank100 first', featuredMission(s.data, { overtakes: 0, distance: 0 }).id === 'bank100');
  t('banked progress tracks lifetime', missionProgress(missionById('bank100'), s.data, {}) === 0);
  s.bankRun(100, { overtakes: 0, distance: 0 });
  t('bank100 auto-completes with +50 reward',
    s.data.missions.bank100.done === true && s.data.coins === 150);
  const c2 = s.checkMissions({ overtakes: 30, distance: 0 });
  t('over30 completes at 30 overtakes', c2.some((m) => m.id === 'over30') && s.data.missions.over30.done);
  t('completed missions do not pay twice', s.checkMissions({ overtakes: 99, distance: 0 }).length === 0);
}

console.log('— Coins / boost —');
t('coin pickup at player pos', coinHit(0, 0, 0, 0, 0.9, 0) === true);
t('coin in other lane not collected', coinHit(-3.2, 0, 0, 0, 0.9, 0) === false);
t('jump-arc coin collected mid-air', coinHit(0, 1.6, 0, 0, 2.1, 0) === true);
t('high coin missed when grounded', coinHit(0, 0, 0, 0, 2.3, 0) === false);
t('boost needs 30+ meter', boostCanStart(100) && boostCanStart(30) && !boostCanStart(29));
t('boost mult sane (1.3..2.0)', CONF.boostMult >= 1.3 && CONF.boostMult <= 2.0);

console.log('— Jump energy meter —');
t('one jump consumes the entire bar', CONF.jumpCost === 100);
t('jump needs a FULL 100% bar', jumpCanStart(100) && !jumpCanStart(99.9) && !jumpCanStart(0));
t('jump recharge rate matches nitro', CONF.jumpRegen === CONF.boostRegen);
t('jump recharge delay matches nitro', CONF.jumpRegenDelay === CONF.boostRegenDelay);
t('jump full-recharge time equals nitro (~8.1s)',
  fullRechargeTime(CONF.jumpRegen, CONF.jumpRegenDelay) === fullRechargeTime(CONF.boostRegen, CONF.boostRegenDelay) &&
  fullRechargeTime(CONF.jumpRegen, CONF.jumpRegenDelay) > 8 && fullRechargeTime(CONF.jumpRegen, CONF.jumpRegenDelay) < 8.5);
t('jump meter does not refill instantly', CONF.jumpRegen < 100 && CONF.jumpRegenDelay > 0);
t('jump and nitro meters are independent systems', CONF.jumpCost !== CONF.boostMin);
t('nitro tuning unchanged', CONF.boostDrain === 34 && CONF.boostRegen === 14 && CONF.boostMin === 30);

console.log('— Power-up upgrades (4 tracks x 5 levels) —');
t('four upgrade tracks in fixed order',
  UPGRADE_IDS.join(',') === 'shield,magnet,coin2x,jump');
t('five levels per track', upgradeLevelMax() === 5 &&
  UPGRADE_IDS.every((id) => UPGRADES[id].durations.length === 5 && UPGRADES[id].prices.length === 4));
t('shield durations 4/5/6/7/8s',
  upgradeDuration('shield', 1) === 4 && upgradeDuration('shield', 3) === 6 && upgradeDuration('shield', 5) === 8);
t('magnet durations 5/6/7/8/10s + strictly wider radius',
  upgradeDuration('magnet', 1) === 5 && upgradeDuration('magnet', 5) === 10 &&
  magnetRadiusFor(1) === 8 && magnetRadiusFor(5) === 15 &&
  magnetRadiusFor(2) > magnetRadiusFor(1) && magnetRadiusFor(3) > magnetRadiusFor(2) &&
  magnetRadiusFor(4) > magnetRadiusFor(3) && magnetRadiusFor(5) > magnetRadiusFor(4));
t('2x durations 6/7/8/10/12s',
  upgradeDuration('coin2x', 1) === 6 && upgradeDuration('coin2x', 3) === 8 && upgradeDuration('coin2x', 5) === 12);
t('jump airtime 1.15s base, longer per level, max 1.60s',
  Math.abs(jumpAirtimeFor(1) - 1.15) < 0.01 && Math.abs(jumpAirtimeFor(5) - 1.60) < 0.01 &&
  jumpAirtimeFor(2) > jumpAirtimeFor(1) && jumpAirtimeFor(5) > jumpAirtimeFor(4));
t('jump gravity weakens (floatier), L1 equals base gravity',
  jumpGravityFor(5) > CONF.gravity && jumpGravityFor(1) === CONF.gravity);
t('upgrade levels clamp to 1..5',
  clampUpgradeLevel(99) === 5 && clampUpgradeLevel(-5) === 1 && clampUpgradeLevel(0) === 1 &&
  upgradeDuration('shield', 99) === upgradeDuration('shield', 5) &&
  magnetRadiusFor(99) === magnetRadiusFor(5));
t('upgrade prices rise per level, null at max',
  upgradePrice('shield', 1) === 100 && upgradePrice('shield', 4) > upgradePrice('shield', 1) &&
  upgradePrice('shield', 5) === null && upgradePrice('jump', 5) === null &&
  upgradePrice('nope', 1) === null);
t('unknown upgrade id is safe (null def, 0 duration)',
  upgradeDef('nope') === null && upgradeDuration('nope', 3) === 0);
t('recharge timing ignores upgrade level',
  fullRechargeTime(CONF.jumpRegen, CONF.jumpRegenDelay) === fullRechargeTime(CONF.boostRegen, CONF.boostRegenDelay));
{
  // Simulate a max-level jump: airtime must match the configured 1.60s.
  let y = 0, vy = CONF.jumpVelocity, air = 0;
  for (let i = 0; i < 600; i++) { const s = stepJump(y, vy, 1 / 60, jumpGravityFor(5)); y = s.y; vy = s.vy; air += 1 / 60; if (s.landed) break; }
  t('level-5 jump lands (~1.60s air)', y === 0 && air > 1.5 && air < 1.7);
}
{
  // SaveData: upgrades deduct, reject, cap, migrate, persist, reset (fake storage).
  const store = {};
  const mem = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
  const s = new SaveData(mem);
  t('fresh save: all upgrades at level 1',
    UPGRADE_IDS.every((id) => s.data.upgrades[id] === 1));
  s.data.coins = 1000;
  const r1 = s.buyUpgrade('shield');
  t('upgrade deducts price + reaches LV2',
    r1.ok && r1.level === 2 && s.data.coins === 1000 - UPGRADES.shield.prices[0] && s.data.upgrades.shield === 2);
  s.data.coins = 10;
  const poor = s.buyUpgrade('shield');
  t('poor upgrade rejected, no deduction',
    !poor.ok && poor.reason === 'coins' && s.data.coins === 10 && s.data.upgrades.shield === 2);
  const bad = s.buyUpgrade('nope');
  t('unknown upgrade rejected', !bad.ok && bad.reason === 'invalid');
  s.data.coins = 50000;
  s.buyUpgrade('magnet'); s.buyUpgrade('magnet'); s.buyUpgrade('magnet'); s.buyUpgrade('magnet');
  const maxed = s.buyUpgrade('magnet');
  t('maxed upgrade rejected at LV5', !maxed.ok && maxed.reason === 'maxed' && s.data.upgrades.magnet === 5);
  const s2 = new SaveData(mem); // reload from same storage
  t('upgrade levels persist across reload',
    s2.data.upgrades.shield === 2 && s2.data.upgrades.magnet === 5);
  // Legacy saves: jumpLevel 0..3 migrates up the 5-level ladder.
  const legacy = { getItem: (k) => (k === 'carway_jumpLevel' ? '2' : null), setItem: () => {} };
  const s3 = new SaveData(legacy);
  t('legacy jumpLevel 2 migrates to jump LV4', s3.data.upgrades.jump === 4);
  // Corrupt levels self-heal; reset wipes progress but keeps prefs.
  s2.data.upgrades.shield = 99;
  s2.validateUpgrades();
  t('corrupt levels clamp on validate', s2.data.upgrades.shield === 5);
  store.carway_quality = 'low'; // game-level pref key, outside SaveData
  s2.resetProgress();
  t('reset wipes progress, keeps prefs',
    s2.data.coins === 0 && s2.data.upgrades.shield === 1 && s2.data.car === 'roadster' &&
    store.carway_quality === 'low');
}

console.log('— Jump-clearance feasibility (front-to-back math) —');
{
  // Slowest traffic crawl: startSpeed x (1 - fastest traffic ratio).
  const relMin = CONF.startSpeed * (1 - CONF.trafficSpeedMax);
  // Fastest approach: maxSpeed x (1 - slowest traffic ratio).
  const relMax = CONF.maxSpeed * (1 - CONF.trafficSpeedMin);
  t('above-clear window sane (sedan ~0.84s)', timeAboveClearance(CONF.clearHeightSedan) > 0.8);
  t('sedan clearable at slowest crawl', canClearJump(4.3, CONF.clearHeightSedan, relMin) === true);
  t('sedan clearable at fastest approach', canClearJump(4.3, CONF.clearHeightSedan, relMax) === true);
  t('SUV clearable at slowest crawl', canClearJump(4.5, CONF.clearHeightSuv, relMin) === true);
  t('SUV clearable at fastest approach', canClearJump(4.5, CONF.clearHeightSuv, relMax) === true);
  t('truck NOT clearable at slow crawl (must dodge)', canClearJump(6.4, CONF.clearHeightTruck, relMin) === false);
  t('truck clearable only at high speed (skill move)', canClearJump(6.4, CONF.clearHeightTruck, relMax) === true);
  // Roadworks are static world objects: relative speed = full player speed.
  t('roadworks always clearable', canClearJump(CONF.worksLen, CONF.clearHeightWorks, CONF.startSpeed) === true);
}

console.log('— Graphics quality tiers —');
t('3 tiers, Medium default', QUALITY_ORDER.length === 3 && DEFAULT_QUALITY === 'medium' &&
  QUALITY_ORDER.includes('low') && QUALITY_ORDER.includes('medium') && QUALITY_ORDER.includes('high'));
t('pixel caps rise with tier (1 / 1.5 / 2)',
  QUALITY_LEVELS.low.pixelRatioCap === 1 && QUALITY_LEVELS.medium.pixelRatioCap === 1.5 &&
  QUALITY_LEVELS.high.pixelRatioCap === 2);
t('shadows off on Low, on above', QUALITY_LEVELS.low.shadows === false &&
  QUALITY_LEVELS.medium.shadows === true && QUALITY_LEVELS.high.shadows === true);
t('vapor budgets rise with tier (20/40/64)',
  QUALITY_LEVELS.low.vaporBudget === 20 && QUALITY_LEVELS.medium.vaporBudget === 40 &&
  QUALITY_LEVELS.high.vaporBudget === 64);
t('LOD range rises with tier (40/55/70)',
  QUALITY_LEVELS.low.lodFar === 40 && QUALITY_LEVELS.medium.lodFar === 55 && QUALITY_LEVELS.high.lodFar === 70);
t('clearcoat paint is High-only', QUALITY_LEVELS.high.physicalPaint === true &&
  QUALITY_LEVELS.medium.physicalPaint === false && QUALITY_LEVELS.low.physicalPaint === false);

console.log('— Auto-quality stepper (pure hysteresis) —');
{
  t('poor window steps down one tier',
    autoQualityStep('high', 'high', 20, 0).quality === 'medium');
  t('poor window bottoms out at low',
    autoQualityStep('low', 'high', 10, 0).quality === 'low');
  t('poor window resets the good streak',
    JSON.stringify(autoQualityStep('medium', 'high', 20, 2)) === JSON.stringify({ quality: 'low', good: 0 }));
  t('first good windows hold + count the streak',
    JSON.stringify(autoQualityStep('medium', 'high', 60, 1)) === JSON.stringify({ quality: 'medium', good: 2 }));
  t('third good window steps up + resets the streak',
    JSON.stringify(autoQualityStep('medium', 'high', 60, 2)) === JSON.stringify({ quality: 'high', good: 0 }));
  t('never steps above the manual ceiling',
    autoQualityStep('medium', 'medium', 60, 2).quality === 'medium');
  t('mid band holds + resets the streak',
    JSON.stringify(autoQualityStep('medium', 'high', 40, 2)) === JSON.stringify({ quality: 'medium', good: 0 }));
  t('unknown tier falls back to the ceiling',
    autoQualityStep('ultra', 'medium', 60, 0).quality === 'medium');
}

console.log('— Traffic palette (player red stays distinctive) —');
{
  const red = paintById('red').color;
  const rr = (red >> 16) & 255, gg = (red >> 8) & 255, bb = red & 255;
  const dist2 = (c) => {
    const r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
    return (r - rr) ** 2 + (g - gg) ** 2 + (b - bb) ** 2;
  };
  t('8 traffic colors, none player-red', TRAFFIC_COLORS.length === 8 && !TRAFFIC_COLORS.includes(red));
  t('every traffic color far from red (dist > 120)',
    TRAFFIC_COLORS.every((c) => Math.sqrt(dist2(c)) > 120));
  t('palette has bright + dark variety',
    new Set(TRAFFIC_COLORS).size === 8 && TRAFFIC_COLORS.some((c) => c > 0x808080) && TRAFFIC_COLORS.some((c) => c < 0x808080));
}

console.log('— Player model envelope (hitbox compatibility) —');
{
  const p = buildPlayerCar();
  const box = new THREE.Box3().setFromObject(p.body);
  const sx = box.max.x - box.min.x, sz = box.max.z - box.min.z;
  t('player footprint stays ~4.4 x 2.0m', Math.abs(sz - 4.4) < 0.3 && Math.abs(sx - 2.0) < 0.3);
  t('player trim never dips below the road', box.min.y >= -0.01);
  t('player has brake bar + spoiler + 4 wheels + torus tires',
    p.wheels.length === 4 && !!p.brakeMat && !!p.boostFlames && p.boostFlames.length === 2);
  t('player exposes underbody + exhaust vapor anchors',
    p.underbody.length === 2 && p.exhausts.length === 2);
  t('player paint swap preserves color count', p.paintMats.length === 2);
}

console.log('— Traffic bodies: envelopes + per-type feasibility —');
{
  const CLEAR = { sedan: CONF.clearHeightSedan, suv: CONF.clearHeightSuv, truck: CONF.clearHeightTruck };
  const relMin = CONF.startSpeed * (1 - CONF.trafficSpeedMax);
  const relMax = CONF.maxSpeed * (1 - CONF.trafficSpeedMin);
  t('9 body styles in pool order, sedan first, tow last',
    BODY_ORDER.length === 9 && BODY_ORDER[0] === 'sedan' && BODY_ORDER[8] === 'tow' && new Set(BODY_ORDER).size === 9);
  let topsOk = true, dimsOk = true, feasOk = true, kindsOk = true, lodOk = true;
  for (const b of BODY_ORDER) {
    const c = buildTrafficCar(b, 0x336699);
    const box = new THREE.Box3().setFromObject(c.detail);
    const top = box.max.y, len = box.max.z - box.min.z, wid = box.max.x - box.min.x;
    const kind = BODY_SPECS[b].kind;
    if (!(top < CLEAR[kind])) { topsOk = false; console.log(`    top FAIL ${b}: ${top.toFixed(2)} >= ${CLEAR[kind]}`); }
    if (Math.abs(len - c.len) > 0.3 || Math.abs(wid - c.wid) > 0.3) { dimsOk = false; console.log(`    dims FAIL ${b}: ${len.toFixed(2)}x${wid.toFixed(2)}`); }
    if (!['sedan', 'suv', 'truck'].includes(kind)) kindsOk = false;
    if (!c.simple || !c.detail || c.paintMats.length !== 2 || c.wheels.length < 4) lodOk = false;
    const feas = kind === 'truck'
      ? (!canClearJump(len, CLEAR[kind], relMin) && canClearJump(len, CLEAR[kind], relMax))
      : (canClearJump(len, CLEAR[kind], relMin) && canClearJump(len, CLEAR[kind], relMax));
    if (!feas) { feasOk = false; console.log(`    feasibility FAIL ${b}`); }
  }
  t('every visual top stays under its class clear height', topsOk);
  t('every visual footprint matches its collision size', dimsOk);
  t('every body maps to a valid clearance class', kindsOk);
  t('every body has detail + simple LOD + recolor mats + 4+ wheels', lodOk);
  t('cars clearable at crawl + speed, truck only at speed', feasOk);
}

console.log('— Tow truck integration (stub scene, no WebGL) —');
{
  const tr = new TrafficSystem({ add() {} });
  const tows = tr.cars.filter((c) => c.body === 'tow');
  t('pool carries exactly 2 tow trucks (occasional by construction)', tows.length === 2);
  t('tow keeps the truck clearance class + lane footprint',
    tows.every((c) => c.kind === 'truck' && c.len === 6.0 && c.wid === 2.10));
  // Spawn-selection mechanism serves tows occasionally, never consecutively.
  tr.reset();
  const served = [];
  for (let i = 0; i < 18; i++) {
    const c = tr._freeCar();
    if (!c) break;
    c.active = true; tr.lastSpawnBody = c.body; served.push(c.body);
  }
  t('selection serves both tows across a full pool cycle',
    served.filter((b) => b === 'tow').length === 2);
  let consecTow = false;
  for (let i = 1; i < served.length; i++) {
    if (served[i] === 'tow' && served[i - 1] === 'tow') consecTow = true;
  }
  t('tows never served consecutively (anti-repeat)', !consecTow);
  // Fair-spawn validator sees real tow footprints.
  tr.reset();
  const tow = tr.cars.find((c) => c.body === 'tow');
  tow.active = true; tow.lane = 1; tow.speed = 10; tow.group.position.set(0, 0, -100);
  const desc = tr._activeDescriptors(20, 0).find((d) => d.lanes[0] === 1);
  const hz = ((CONF.playerLength / 2) * CONF.hitShrinkZ) + ((tow.len / 2) * CONF.hitShrinkZ);
  t('validator uses the real tow footprint', !!desc && Math.abs(((desc.z1 - desc.z0) / 2) - hz) < 1e-9);
  const plan = tr._planRow(0, 20, CONF.spawnZ);
  t('validator still plans fair rows with a tow live', !plan || plan.lanes.length <= 2);
  // Cleanup paths clear tows like any car.
  tow.group.position.z = CONF.despawnZ + tow.len + 1;
  tr.update(0.016, 20, 0, 0);
  t('tow despawns past the limit (pooled, not leaked)', tow.active === false && tow.group.visible === false);
  tow.active = true; tow.group.visible = true; tow._hitMark = true;
  tr.reset();
  t('reset() clears tow state', tow.active === false && tow._hitMark === false);
}

console.log('— Traffic variety + LOD (stub scene, no WebGL) —');
{
  const tr = new TrafficSystem({ add() {} });
  t('pool has 18 cars cycling all 9 bodies',
    tr.cars.length === 18 && new Set(tr.cars.map((c) => c.body)).size === 9 && tr.cars[0].body === 'sedan');
  // Spawn several batches (draining between) so the pool never exhausts.
  for (let batch = 0; batch < 3; batch++) {
    for (let i = 0; i < 8; i++) tr._spawnRow(0, 20);
    for (const c of tr.cars) { c.active = false; c.group.visible = false; }
  }
  const bodies = tr.spawnedBodies, colors = tr.spawnedColors;
  let consecBody = false, consecColor = false;
  for (let i = 1; i < bodies.length; i++) if (bodies[i] === bodies[i - 1]) consecBody = true;
  for (let i = 1; i < colors.length; i++) if (colors[i] === colors[i - 1]) consecColor = true;
  t('no consecutive identical bodies', !consecBody);
  t('no consecutive identical colors', !consecColor);
  t('spawn variety: 4+ distinct bodies', new Set(bodies).size >= 4);
  t('spawned colors never player-red', !colors.includes(paintById('red').color));
  // LOD sync: teleport one car far/near, updates must flip the levels.
  tr.reset();
  const c = tr.cars[0];
  c.active = true; c.speed = 10; c.group.position.set(0, 0, -120);
  tr.update(0.016, 20, 0, 0);
  t('far car uses simple LOD', c.simple.visible === true && c.detail.visible === false);
  c.group.position.z = -10;
  tr.update(0.016, 20, 0, 0);
  t('near car uses detail LOD', c.detail.visible === true && c.simple.visible === false);
}

console.log('— Collision classification (rear vs side) —');
// Min-penetration axis on the FIRST overlapping frame (= entry geometry,
// since each obstacle fires exactly one event per spawn via hitMark).
t('dead-center overlap = rear (head-on, not a scrape)', classifyCollision(0, 0, 0, 0, 4.2, 2.0) === 'rear');
t('rear-ender entry (shallow z overlap) = rear', classifyCollision(0, 0, 0, -2.9, 4.2, 2.0) === 'rear');
t('centered shallow overlap = rear', classifyCollision(0, 0, 0, -2.0, 4.2, 2.0) === 'rear');
t('side scrape entry (shallow x overlap) = side', classifyCollision(1.35, 0, 0, 0.3, 4.2, 2.0) === 'side');
t('diagonal mostly-behind = rear', classifyCollision(0.8, 0, 0, -2.9, 4.2, 2.0) === 'rear');
t('diagonal mostly-beside = side', classifyCollision(1.4, 0, 0, -1.0, 4.2, 2.0) === 'side');
t('non-overlapping contact = null (no event)', classifyCollision(3.2, 0, 0, 0, 4.2, 2.0) === null);
t('works-size obstacle classifies too', classifyCollision(1.35, 0, 0, 0.5, CONF.worksLen, CONF.worksWid) === 'side');

console.log('— 2x coin awards (exactly once) —');
t('no multiplier: base passes through', coinAward(1, false) === 1 && coinAward(2, false) === 2);
t('multiplier: base doubled exactly once', coinAward(1, true) === 2 && coinAward(2, true) === 4);
t('zero awards stay zero', coinAward(0, true) === 0);
t('pure function: same input, same output', coinAward(3, true) === coinAward(3, true));
t('overtake bundle doubles as one award (2*2=4)', coinAward(2 * CONF.coinsPerOvertake, true) === 8);

console.log('— Garage cars —');
t('4 cars: roadster first + free', CARS.length === 4 && CARS[0].id === 'roadster' && CARS[0].price === 0);
t('prices ascend (600/900/1200)', CARS[1].price === 600 && CARS[2].price === 900 && CARS[3].price === 1200);
t('4 distinct bodies', new Set(CARS.map((c) => c.body)).size === 4);
t('carById falls back to roadster', carById('nope').id === 'roadster' && carById('supercar').body === 'supercar');
{
  const s = new SaveData(null);
  t('fresh save: roadster owned + selected', s.ownsCar('roadster') && s.data.car === 'roadster');
  t('fresh save: no paid cars', s.data.cars.length === 1 && !s.ownsCar('volt'));
  const poor = s.buyCar(carById('supercar'));
  t('cannot buy car without coins (no deduction)',
    poor.ok === false && poor.reason === 'coins' && s.data.coins === 0 && !s.ownsCar('supercar'));
  s.bankRun(1000, { overtakes: 0, distance: 0 }); // 1000 + 50 bank100 reward = 1050
  const bought = s.buyCar(carById('coupe'));
  t('valid car purchase deducts + unlocks + selects',
    bought.ok && s.data.coins === 450 && s.ownsCar('coupe') && s.data.car === 'coupe');
  t('re-buy owned car is free + reselects', s.buyCar(carById('coupe')).ok && s.data.coins === 450);
  t('cannot select unowned car', s.selectCar('supercar') === false && s.data.car === 'coupe');
  t('select owned car works', s.selectCar('roadster') === true && s.data.car === 'roadster');
  s.data.coins = 1000;
  s.buyCar(carById('volt'));
  t('second car purchase stacks ownership',
    s.ownsCar('volt') && s.ownsCar('coupe') && s.data.car === 'volt' && s.data.coins === 100);
}
{
  // Legacy saves (pre-cars) migrate: roadster granted, valid selections
  // survive, invalid selections fall back to roadster.
  const store = {};
  const mem = { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
  const s = new SaveData(mem);
  t('legacy save gains roadster car', s.ownsCar('roadster') && s.data.car === 'roadster');
  mem.setItem('carway_cars', JSON.stringify(['roadster', 'volt']));
  mem.setItem('carway_car', JSON.stringify('volt'));
  const s2 = new SaveData(mem);
  t('valid legacy car selection survives', s2.data.car === 'volt' && s2.ownsCar('volt'));
  mem.setItem('carway_car', JSON.stringify('batmobile'));
  const s3 = new SaveData(mem);
  t('invalid legacy car selection falls back to roadster', s3.data.car === 'roadster');
  const s4 = new SaveData(mem); // persistence round-trip
  t('car ownership persists across reload', s4.ownsCar('volt') && s4.data.car === 'roadster');
}

console.log('— Player garage bodies (hitbox-compatible, distinct) —');
{
  // All player cars share one hitbox (uniform handling); kit shells are
  // normalized to fit it, so the collision box stays honest for every car.
  const tops = [];
  let envOk = true, partsOk = true;
  for (const c of CARS) {
    const p = buildPlayerCar(c.body);
    const box = new THREE.Box3().setFromObject(p.body);
    const sx = box.max.x - box.min.x, sz = box.max.z - box.min.z;
    tops.push(box.max.y);
    if (sz > 4.65 || sx > 2.2 || box.min.y < -0.01) {
      envOk = false; console.log(`    envelope FAIL ${c.body}: ${sz.toFixed(2)}x${sx.toFixed(2)} minY=${box.min.y.toFixed(2)}`);
    }
    if (p.wheels.length !== 4 || !p.brakeMat || p.boostFlames.length !== 2 ||
        p.underbody.length !== 2 || p.exhausts.length !== 2 || p.paintMats.length !== 2) {
      partsOk = false; console.log(`    parts FAIL ${c.body}`);
    }
  }
  t('every garage body fits the shared hitbox envelope, never below road', envOk);
  t('every garage body keeps wheels/brakes/flames/anchors/paint', partsOk);
  const kitSpecs = CARS.slice(1).map((c) => c.body);
  t('kit bodies have distinct specs (dims/cabin/extras)',
    new Set(kitSpecs.map((b) => JSON.stringify(BODY_SPECS[b]))).size === 3);
  t('kit bodies wear distinct extras',
    new Set(kitSpecs.map((b) => BODY_SPECS[b].extras.join('+'))).size === 3);
  t('silhouettes differ (roof span > 0.15m)',
    Math.max(...tops) - Math.min(...tops) > 0.15);
  const nopeBox = new THREE.Box3().setFromObject(buildPlayerCar('nope').body);
  const roadBox = new THREE.Box3().setFromObject(buildPlayerCar('roadster').body);
  t('unknown body falls back to roadster',
    nopeBox.max.equals(roadBox.max) && nopeBox.min.equals(roadBox.min));
}

console.log('— Power-up + police tuning —');
t('shield L1 lasts 4s (8s maxed)', upgradeDuration('shield', 1) === 4 && upgradeDuration('shield', 5) === 8);
t('2x coins L1 last 6s (12s maxed)', upgradeDuration('coin2x', 1) === 6 && upgradeDuration('coin2x', 5) === 12);
t('magnet L1 lasts 5s (10s maxed)', upgradeDuration('magnet', 1) === 5 && upgradeDuration('magnet', 5) === 10);
t('chase lasts 8s', CONF.chaseDuration === 8);
t('billboards enabled, 2 spots per plain', BILLBOARDS.enabled && BILLBOARDS.spots.length === 2);
t('billboard face square, art fits inside',
  BILLBOARDS.boardW === BILLBOARDS.boardH && BILLBOARDS.artSize < BILLBOARDS.boardW);
t('billboard poles clear the rails with margin',
  BILLBOARDS.roadGap - BILLBOARDS.poleDx - 0.2 > CONF.roadWidth / 2 + 0.9 + 0.5);
t('shield break grants >1s grace', CONF.shieldGrace >= 1);
t('pickups spawn sparsely (140m..240m)', CONF.pickupGapMin === 140 && CONF.pickupGapMax === 240);
t('police follows 6.5m behind (z+), damp rate 3',
  CONF.policeFollowZ === 6.5 && CONF.policeFollowRate === 3);

console.log('— Pickups system (stub scene, no WebGL) —');
{
  const pk = new PickupsSystem({ add() {} });
  t('pool of 5, all parked invisible', pk.items.length === 5 && pk.items.every((p) => !p.active && !p.root.visible));
  t('fresh orbs have no type yet', pk.items.every((p) => p.type === null));
  t('collect on inactive pickup returns null', pk.collect(pk.items[0]) === null);
  pk._spawn(); pk._spawn();
  const live = pk.items.filter((p) => p.active);
  t('spawned orbs are live with a valid type',
    live.length === 2 && live.every((p) => (p.type === 'shield' || p.type === 'coin2x' || p.type === 'magnet') && p.root.visible));
  t('spawned orbs show only their own visual',
    live.every((p) => p.shieldMesh.visible === (p.type === 'shield') && p.coinMesh.visible === (p.type === 'coin2x') &&
      p.magnetMesh.visible === (p.type === 'magnet')));
  const type = pk.collect(live[0]);
  t('collect returns type + parks orb',
    (type === 'shield' || type === 'coin2x' || type === 'magnet') && !live[0].active && live[0].type === null && !live[0].root.visible);
  live[1].root.position.z = 11.9;
  pk.update(0.1, 20, 0);
  t('orbs despawn past the camera (z > 12)', !live[1].active && !live[1].root.visible);
  pk._spawn(); pk.reset();
  t('reset parks every orb', pk.items.every((p) => !p.active && p.type === null && !p.root.visible));
}

console.log('— Police system (stub scene, no WebGL) —');
{
  const po = new PoliceSystem({ add() {} });
  t('starts idle + invisible', po.active === false && po.leaving === false && !po.group.visible);
  t('beacons are a private red/blue pair',
    po.beaconR.color.getHex() === 0xff2222 && po.beaconB.color.getHex() === 0x2255ff);
  po.spawn(1.5);
  t('spawn pursues from behind, visible',
    po.active && !po.leaving && po.group.visible && po.group.position.z > CONF.policeFollowZ);
  const z0 = po.group.position.z;
  po.update(0.5, 1.5, 20);
  t('follow closes the gap + aligns lane',
    po.group.position.z < z0 && Math.abs(po.group.position.x - 1.5) < 0.6);
  const r0 = po.beaconR.emissiveIntensity;
  po.update(0.3, 1.5, 20);
  t('beacons strobe while active (intensity flips)', po.beaconR.emissiveIntensity !== r0);
  po.startLeave();
  t('startLeave flags leaving (still active)', po.leaving === true && po.active === true);
  for (let i = 0; i < 20; i++) po.update(0.5, 0, 20);
  t('leave mode falls back + parks invisible', po.active === false && !po.group.visible);
  po.spawn(-2); po.reset();
  t('reset returns to idle + invisible', !po.active && !po.leaving && !po.group.visible);
}

console.log('— Siren is headless-safe (no AudioContext in node) —');
{
  const snd = new SoundSystem();
  let threw = false;
  try { snd.pickup(); snd.shieldBreak(); snd.startSiren(); snd.stopSiren(); snd.stopSiren(); } catch (e) { threw = true; }
  t('pickup/shield/siren calls never throw without audio', !threw && snd.sirenOsc == null);
}


// ---- Fair-spawn validator: pure core units (deterministic) ----
{
  // tail edge arrives first, nose last; margin = 12% of t0 (min 0.3 s).
  const w = fairWindow({ lanes: [1], z0: -32, z1: -28, relLo: 10, relHi: 10 }, 0);
  t('fairWindow arrival order + margin',
    !!w && Math.abs(w.t0 - 2.464) < 1e-9 && Math.abs(w.t1 - 3.536) < 1e-9);
  t('fairWindow null when fully passed', fairWindow({ lanes: [0], z0: 2, z1: 6, relLo: 10, relHi: 10 }, 0) === null);
  t('fairWindow null when receding', fairWindow({ lanes: [0], z0: -30, z1: -26, relLo: -2, relHi: 0 }, 0) === null);
  const e = fairWindow({ lanes: [1], z0: -32, z1: -28, relLo: 10, relHi: 16 }, 0);
  t('fairWindow envelope spans boost regimes', !!e && Math.abs(e.t0 - 1.45) < 1e-9 && Math.abs(e.t1 - 3.5) < 1e-9);
  const A = { lanes: [0], z0: -32, z1: -28, relLo: 10, relHi: 10 };
  const B = { lanes: [1], z0: -40, z1: -36, relLo: 10, relHi: 10 };   // overlaps A -> same cluster
  const C = { lanes: [2], z0: -90, z1: -86, relLo: 10, relHi: 10 };   // far -> own cluster
  const cl = clusterObstacles([C, A, B], 0);
  t('clusterObstacles groups transitively + sorts by encounter',
    cl.length === 2 && JSON.stringify(cl[0].lanes) === '[0,1]' && JSON.stringify(cl[1].lanes) === '[2]');
  t('minLaneChanges counts fewest switches',
    minLaneChanges([2], [0, 1]) === 1 && minLaneChanges([0], [0, 2]) === 0 && minLaneChanges([0], [2]) === 2);
  t('fairTimeGap = reaction + switches',
    fairTimeGap(2) === CONF.fairReactT + 2 * CONF.fairSwitchT);
  const wall = [{ lanes: [0, 1, 2], t0: 1, t1: 2 }];
  t('fieldViolations flags 3-lane walls',
    fieldViolations(wall).length === 1 && fieldViolations(wall)[0].type === 'wall');
  const tight = [{ lanes: [0, 1], t0: 1, t1: 2 }, { lanes: [1, 2], t0: 2.1, t1: 3 }];
  t('fieldViolations flags unreachable escapes',
    fieldViolations(tight).length === 1 && fieldViolations(tight)[0].type === 'gap');
  const roomy = [{ lanes: [0, 1], t0: 1, t1: 2 }, { lanes: [1, 2], t0: 4, t1: 5 }];
  t('fieldViolations accepts reachable escapes', fieldViolations(roomy).length === 0);
  const hold = [{ lanes: [0, 1], t0: 1, t1: 2 }, { lanes: [0], t0: 2.01, t1: 3 }];
  t('fieldViolations: holding a lane needs no gap', fieldViolations(hold).length === 0);
}

// ---- Fair-spawn validator: 6000 m long-run property test ----
// Drives the REAL TrafficSystem.update (spawn cadence, merge-prone speeds,
// boost phases, roadworks) and audits every 0.5 s. Any 3-lane wall or
// unreachable escape anywhere in the run fails.
{
  const tr = new TrafficSystem({ add() {} });
  const dt = 1 / 60;
  let dist = 0, samples = 0, violations = 0, firstV = null;
  while (dist < 6000) {
    let sp = playerSpeedFor(dist);
    if ((dist % 800) < 90) sp *= CONF.boostMult; // ~3 s boost every 800 m
    tr.update(dt, sp, dist, 0);
    dist += sp * dt;
    samples++;
    if (samples % 30 === 0) {
      const a = tr.auditFairness(sp, dist);
      if (a.violations.length) {
        violations += a.violations.length;
        if (!firstV) firstV = `dist=${Math.round(dist)} ${JSON.stringify(a.violations[0])}`;
      }
    }
  }
  console.log(`   (sim: cars=${tr.carsSpawned} rows=${tr.rowsSpawned} delayed=${tr.rowsDelayed} retries=${tr._validatorRetries})`);
  if (firstV) console.log('   first violation: ' + firstV);
  t('6000m sim: zero fairness violations (no walls, all escapes reachable)', violations === 0);
  t('6000m sim: traffic stays dense (>= 3 cars/100m)', tr.carsSpawned / 60 >= 3);
  t('6000m sim: delays bounded (< 20% of rows)', tr.rowsDelayed / Math.max(1, tr.rowsSpawned) < 0.2);
  t('6000m sim: validator engaged (first picks rejected)', tr._validatorRetries > 0);
}

// ---- Fair-spawn validator: delay path (deterministic, rigged field) ----
{
  const tr = new TrafficSystem({ add() {} });
  // Saturated field: two envelope-clusters whose union is all 3 lanes, with
  // the spawn window bridging both — EVERY candidate merges into a wall.
  tr._activeDescriptors = () => ([
    { lanes: [0, 1], z0: -76, z1: -70, relLo: 12, relHi: 25 },
    { lanes: [0, 2], z0: -121, z1: -115, relLo: 2, relHi: 15.2 },
  ]);
  const realRandom = Math.random;
  Math.random = () => 0.5; // deterministic draws: z=-123, ratio=0.5
  tr._spawnRow(100, 22);
  Math.random = realRandom;
  t('saturated field delays the row instead of forcing a wall',
    tr.rowsDelayed === 1 && tr.rowsSpawned === 0);
}
{
  const tr = new TrafficSystem({ add() {} });
  for (const c of tr.cars) c.active = true; // pool exhausted
  tr._spawnRow(100, 22);
  t('pool exhaustion skips spawn without crashing', tr.rowsSpawned === 0);
  t('pool exhaustion is not counted as a fairness delay', tr.rowsDelayed === 0);
}


// ---- Side-contact resolution math (pure, deterministic) ----
{
  const r = sidePushOut(1.0, 3.2, 2.0);
  t('sidePushOut separates to the x boundary',
    Math.abs(r.x - 1.76) < 1e-9 && r.dir === -1 && Math.abs(r.maxDx - 1.44) < 1e-9);
  const l = sidePushOut(-1.0, -3.2, 2.0);
  t('sidePushOut mirrors left', Math.abs(l.x + 1.76) < 1e-9 && l.dir === 1);
  const at = sidePushOut(1.76, 3.2, 2.0);
  t('sidePushOut idempotent at the boundary', Math.abs(at.x - 1.76) < 1e-9);
  // No-tunnel proof pins: max single-frame steps stay inside the windows
  // (dt clamp 0.05, single-lane switches, widest/shortest traffic sizes).
  const latStep = CONF.laneWidth * Math.min(1, 0.05 * CONF.laneChangeRate);
  const latWindow = 2 * ((CONF.playerWidth + 2.1) / 2) * CONF.hitShrinkX;
  t('lateral step cannot tunnel the x window', latStep < latWindow);
  const zStep = CONF.maxSpeed * 0.05;
  const zWindow = 2 * ((CONF.playerLength + 3.9) / 2) * CONF.hitShrinkZ;
  t('longitudinal step cannot tunnel the z window', zStep < zWindow);
  t('dead-center overlap still rear (push never fires)',
    classifyCollision(0, 0, 0, 0, 4.2, 2.0) === 'rear');
}


// ---- Side-impact sound routing + mute (counting fake AudioContext) ----
{
  const s = new SoundSystem();
  let nodes = 0;
  const fakeParam = () => ({ setValueAtTime() {}, exponentialRampToValueAtTime() {} });
  const link = (n) => n; // connect() returns its argument, like WebAudio
  s.ctx = {
    currentTime: 0, sampleRate: 44100, destination: {},
    createOscillator: () => { nodes++; return { type: '', frequency: fakeParam(), connect: link, start() {}, stop() {} }; },
    createGain: () => ({ gain: fakeParam(), connect: link }),
    createBuffer: () => ({ getChannelData: () => new Float32Array(64) }),
    createBufferSource: () => { nodes++; return { buffer: null, connect: link, start() {} }; },
    createBiquadFilter: () => ({ type: '', frequency: fakeParam(), connect: link }),
  };
  s.sfxBus = { gain: { value: 1 }, connect: link };
  s.muted = false;
  s.scrape();
  t('scrape() emits a thump through the sfx path', nodes === 2);
  nodes = 0;
  s.muted = true;
  s.scrape();
  t('scrape() silent when muted', nodes === 0);
  nodes = 0;
  s.muted = false;
  s.crash();
  t('crash() still emits (rear/game-over audio intact)', nodes === 3);
}

console.log(`\n${pass} passed, ${fail} failed.`);
process.exit(fail ? 1 : 0);
